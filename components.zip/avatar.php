<?php
function generateAvatar($username, $size = 400) { // Increased default size
    // Create a blank image with higher resolution
    $image = imagecreatetruecolor($size, $size);
    
    // Enable alpha blending
    imagealphablending($image, true);
    imagesavealpha($image, true);
    
    // Generate colors based on username
    $hash = md5($username);
    
    // Create more sophisticated colors
    $hue = hexdec(substr($hash, 0, 2)) / 255;
    list($r, $g, $b) = hslToRgb($hue, 0.7, 0.6); // More saturated, controlled brightness
    
    // Allocate colors
    $background = imagecolorallocate($image, $r, $g, $b);
    $textColor = imagecolorallocate($image, 255, 255, 255);
    $darker = imagecolorallocate($image, $r*0.6, $g*0.6, $b*0.6);
    $lighter = imagecolorallocate($image, min(255, $r*1.3), min(255, $g*1.3), min(255, $b*1.3));

    // Create gradient background
    imagefilledrectangle($image, 0, 0, $size, $size, $background);
    
    // Add subtle patterns
    for($i = 0; $i < $size; $i += 4) {
        imageline($image, 0, $i, $size, $i, $darker);
    }
    
    // Add circular overlay
    $circle_size = $size * 0.9;
    imagefilledellipse($image, $size/2, $size/2, $circle_size, $circle_size, $lighter);
    
    // Get initials (up to 2 characters)
    $initials = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', 
        substr($username, 0, 2)));

    // Load font (using a better font if available)
    $font = __DIR__ . '/arial.ttf';  // Consider using a better font

    // Calculate font size and position
    $fontSize = $size * 0.45;
    $textBox = imagettfbbox($fontSize, 0, $font, $initials);
    $textWidth = $textBox[2] - $textBox[0];
    $textHeight = $textBox[1] - $textBox[7];
    $x = ($size - $textWidth) / 2;
    $y = ($size + $textHeight) / 2;

    // Add multiple layer text shadow for depth
    imagettftext($image, $fontSize, 0, $x+3, $y+3, $darker, $font, $initials);
    imagettftext($image, $fontSize, 0, $x+2, $y+2, $darker, $font, $initials);
    imagettftext($image, $fontSize, 0, $x, $y, $textColor, $font, $initials);

    // Enable anti-aliasing
    imageantialias($image, true);

    // Output with maximum quality
    header('Content-Type: image/png');
    imagepng($image, null, 1); // Highest quality (1)
    imagedestroy($image);
}

// Helper function to convert HSL to RGB
function hslToRgb($h, $s, $l) {
    $r = $g = $b = $l;
    if ($s != 0) {
        $q = $l < 0.5 ? $l * (1 + $s) : $l + $s - $l * $s;
        $p = 2 * $l - $q;
        $r = hue2rgb($p, $q, $h + 1/3);
        $g = hue2rgb($p, $q, $h);
        $b = hue2rgb($p, $q, $h - 1/3);
    }
    return [round($r * 255), round($g * 255), round($b * 255)];
}

function hue2rgb($p, $q, $t) {
    if ($t < 0) $t += 1;
    if ($t > 1) $t -= 1;
    if ($t < 1/6) return $p + ($q - $p) * 6 * $t;
    if ($t < 1/2) return $q;
    if ($t < 2/3) return $p + ($q - $p) * (2/3 - $t) * 6;
    return $p;
}

// Sanitize input
$username = isset($_GET['username']) ? htmlspecialchars($_GET['username']) : 'Unknown';
$size = isset($_GET['size']) ? min(max((int)$_GET['size'], 32), 1000) : 400;

// Generate the avatar
generateAvatar($username, $size);