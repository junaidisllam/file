<?php session_start(); ?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>কুইজ মাফিয়া - AI কুইজ অ্যাপ্লিকেশন</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        
        .typewriter-container {
            position: relative;
            display: inline-block;
        }
        .typewriter {
            border-right: 3px solid #3B82F6;
            overflow: hidden;
            display: inline-block;
        }
        @keyframes typing {
            from { width: 0 }
            to { width: 100% }
        }
        @keyframes blink-cursor {
            from, to { border-color: transparent }
            50% { border-color: #3B82F6 }
        }
        .wave {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
            line-height: 0;
        }
        .wave svg {
            position: relative;
            display: block;
            width: calc(100% + 1.3px);
            height: 150px;
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <?php include "./components/navbar.php"; ?>
    <!-- Hero Section -->
    <section id="home" class=" pt-32 pb-24 relative bg-blue-50 overflow-hidden">
        <!-- Animated Background Elements -->
        <div class="absolute inset-0 overflow-hidden">
            <!-- Floating Circles -->
            <div class="circle-1 w-32 h-32 bg-blue-200 rounded-full absolute top-20 left-10 animate-float opacity-50"></div>
            <div class="circle-2 w-24 h-24 bg-purple-200 rounded-full absolute top-40 right-20 animate-float-delayed opacity-40"></div>
            <div class="circle-3 w-16 h-16 bg-pink-200 rounded-full absolute bottom-20 left-1/4 animate-float opacity-30"></div>
            
            <!-- Light Beams -->
            <div class="light-beam-1 absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-400/20 to-transparent rotate-45 blur-3xl"></div>
            <div class="light-beam-2 absolute -bottom-20 -right-20 w-96 h-96 bg-gradient-to-l from-purple-400/20 to-transparent rotate-45 blur-3xl"></div>
        </div>

        <div class="wave rounded-4xl absolute top-0 left-0 right-0">
            <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".15" class="fill-current text-indigo-200 animate-pulse"></path>
                <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".3" class="fill-current text-blue-200"></path>
                <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" opacity=".4" class="fill-current text-blue-100 animate-pulse"></path>
                <path d="M0,0V12C158.5,89,319,82.5,478,47c43-9.67,84-25.44,127-33.4,59-10.94,112.5,15.5,165.5,44.8C829.5,85.5,886,108,951,101.5c86.5-8.87,172.5-57.9,249-107.5V0Z" opacity=".25" class="fill-current text-purple-100"></path>
            </svg>
        </div>

        <div class="container mx-auto px-4 text-center relative z-10">
            <h1 class="text-4xl md:text-6xl font-bold text-blue-800 mb-6 leading-tight">
                স্বাগতম <span class="font-bold text-purple-500 relative">
                    কুইজ মাফিয়া
                </span>-এ
                <div class="typewriter-container mt-4 block">
                    <span id="typewriter" class="typewriter text-xl md:text-2xl text-blue-800"></span>
                </div>
            </h1>
            <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center mt-8">
                <a href="/start" class="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition transform hover:-translate-y-1 hover:shadow-blue-500/25 flex items-center justify-center group">
                    <i class="fas fa-play-circle mr-2 text-xl group-hover:rotate-12 transition-transform"></i>
                    কুইজ শুরু করুন
                </a>
                <a href="/leaderboard" class="bg-white hover:bg-gray-50 text-blue-500 font-bold py-3 px-8 rounded-lg shadow-lg border-2 border-blue-500 transition transform hover:-translate-y-1 hover:shadow-blue-500/25 flex items-center justify-center group">
                    <i class="fas fa-trophy mr-2 group-hover:scale-110 transition-transform"></i>
                    লিডারবোর্ড
                </a>
            </div>
        </div>
    </section>

    <style>
    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-20px); }
        100% { transform: translateY(0px); }
    }
    
    @keyframes float-delayed {
        0% { transform: translateY(-20px); }
        50% { transform: translateY(0px); }
        100% { transform: translateY(-20px); }
    }
    
    .animate-float {
        animation: float 6s ease-in-out infinite;
    }
    
    .animate-float-delayed {
        animation: float-delayed 7s ease-in-out infinite;
    }
    </style>
    <!-- Features Section -->
    <section id="features" class="py-24 bg-gradient-to-b from-white to-blue-50">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <span class="text-blue-600 font-semibold text-sm tracking-wider uppercase mb-2 inline-block">অনন্য বৈশিষ্ট্যসমূহ</span>
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">আমাদের <span class="text-blue-600">বৈশিষ্ট্য</span></h2>
                <p class="text-gray-600 text-lg leading-relaxed">আধুনিক প্রযুক্তি ব্যবহার করে আমরা আপনার শিক্ষা যাত্রাকে করে তুলেছি আরও সহজ এবং আনন্দদায়ক</p>
                <div class="h-1.5 w-24 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-7xl mx-auto">
                <!-- Feature Card 1 -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-robot text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-blue-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4 group-hover:text-blue-600 transition-colors duration-300">এডাপ্টিভ AI লার্নিং</h3>
                    <p class="text-gray-600 leading-relaxed">আপনার দক্ষতা অনুযায়ী স্বয়ংক্রিয়ভাবে প্রশ্নের কঠিনতা সামঞ্জস্য করে আপনাকে এগিয়ে নিয়ে যায়</p>
                </div>
                
                <!-- Feature Card 2 -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-trophy text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-purple-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4 group-hover:text-purple-600 transition-colors duration-300">লিডারবোর্ড প্রতিযোগিতা</h3>
                    <p class="text-gray-600 leading-relaxed">অন্যান্য শিক্ষার্থীদের সাথে প্রতিযোগিতা করে নিজেকে প্রমাণ করুন এবং অর্জন করুন শীর্ষ স্থান</p>
                </div>

                <!-- Feature Card 3 -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-chart-line text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-teal-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4 group-hover:text-teal-600 transition-colors duration-300">বিশদ প্রগতি রিপোর্ট</h3>
                    <p class="text-gray-600 leading-relaxed">বিস্তারিত এনালিটিক্স এর মাধ্যমে আপনার শেখার অগ্রগতি পর্যবেক্ষণ করুন এবং উন্নত করুন</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Class Categories -->
    <section id="classes" class="py-24 bg-gradient-to-b from-blue-50 via-white to-blue-50">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-20">
                <span class="text-blue-600 font-semibold text-sm tracking-wider uppercase mb-2 inline-block">আপনার শ্রেণী বাছাই করুন</span>
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">শ্রেণী অনুযায়ী <span class="text-blue-600">কুইজ</span></h2>
                <p class="text-gray-600 text-lg leading-relaxed">আপনার শ্রেণী অনুযায়ী উপযুক্ত কুইজ বেছে নিয়ে আজই শুরু করুন আপনার জ্ঞান যাত্রা</p>
                <div class="h-1.5 w-24 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
                <!-- Class 6 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-blue-400 to-blue-600 flex items-center justify-center">
                        <span class="text-white text-8xl font-bold group-hover:scale-125 transform transition-transform duration-500">৬</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">ষষ্ঠ শ্রেণী</h3>
                        <a href="/class/6/books" class="block w-full bg-white text-blue-600 border-2 border-blue-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>

                <!-- Class 7 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-green-400 to-green-600 flex items-center justify-center">
                        <span class="text-white text-8xl font-bold group-hover:scale-125 transform transition-transform duration-500">৭</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">সপ্তম শ্রেণী</h3>
                        <a href="/class/7/books" class="block w-full bg-white text-green-600 border-2 border-green-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>

                <!-- Class 8 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-purple-400 to-purple-600 flex items-center justify-center">
                        <span class="text-white text-8xl font-bold group-hover:scale-125 transform transition-transform duration-500">৮</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">অষ্টম শ্রেণী</h3>
                        <a href="/class/8/books" class="block w-full bg-white text-purple-600 border-2 border-purple-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>

                <!-- Class 9-10 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-pink-400 to-pink-600 flex items-center justify-center">
                        <span class="text-white text-7xl font-bold group-hover:scale-125 transform transition-transform duration-500">৯-১০</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">নবম-দশম শ্রেণী</h3>
                        <a href="/class/9/books" class="block w-full bg-white text-pink-600 border-2 border-pink-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- AI Tools Section -->
    <section id="ai-tools" class="py-24 bg-gradient-to-b from-white to-blue-50">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <span class="text-blue-600 font-semibold text-sm tracking-wider uppercase mb-2 inline-block">AI টুলস</span>
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">আমাদের <span class="text-blue-600">AI টুলস</span></h2>
                <p class="text-gray-600 text-lg leading-relaxed">আধুনিক AI প্রযুক্তি ব্যবহার করে আপনার শিক্ষা যাত্রাকে করে তুলুন আরও সহজ</p>
                <div class="h-1.5 w-24 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
                <!-- Math Master -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-calculator text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-blue-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">ম্যাথ মাস্টার</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">গণিতের সমস্যা সমাধান এবং ধাপে ধাপে সমাধান প্রক্রিয়া দেখুন</p>
                    <button disabled class="inline-block bg-gray-400 text-white font-bold py-3 px-6 rounded-lg shadow-lg cursor-not-allowed">
                        <i class="fas fa-clock mr-2"></i>
                        খুব শীঘ্রই আসছে
                    </button>
                </div>

                <!-- English Master -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-language text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-green-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">ইংলিশ মাস্টার</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">ইংরেজি ভাষা শিখুন এবং অনুবাদ করুন AI এর সাহায্যে</p>
                    <button disabled class="inline-block bg-gray-400 text-white font-bold py-3 px-6 rounded-lg shadow-lg cursor-not-allowed">
                        <i class="fas fa-clock mr-2"></i>
                        খুব শীঘ্রই আসছে
                    </button>
                </div>

                <!-- Coming Soon -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-gray-100">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-gray-400 to-gray-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-clock text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-gray-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">আরও আসছে...</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">নতুন AI টুলস খুব শীঘ্রই যুক্ত হবে</p>
                    <button disabled class="inline-block bg-gray-400 text-white font-bold py-3 px-6 rounded-lg shadow-lg cursor-not-allowed">
                        <i class="fas fa-clock mr-2"></i>
                        অপেক্ষায় থাকুন
                    </button>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonials Section -->
    <section id="testimonials" class="py-24 bg-gradient-to-b from-blue-50 to-white relative overflow-hidden">
        <!-- Decorative Elements -->
        <div class="absolute inset-0">
            <div class="absolute top-10 left-10 w-20 h-20 bg-blue-100 rounded-full opacity-50"></div>
            <div class="absolute bottom-10 right-10 w-32 h-32 bg-purple-100 rounded-full opacity-50"></div>
            <div class="absolute top-1/2 right-1/4 w-16 h-16 bg-pink-100 rounded-full opacity-30"></div>
        </div>

        <div class="container mx-auto px-4 relative z-10">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <span class="text-blue-600 font-semibold text-sm tracking-wider uppercase mb-2 inline-block">অভিজ্ঞতা শেয়ার</span>
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">শিক্ষার্থীদের <span class="text-blue-600">অভিমত</span></h2>
                <p class="text-gray-600 text-lg leading-relaxed">আমাদের প্ল্যাটফর্মে শিক্ষার্থীদের অভিজ্ঞতা জানুন</p>
                <div class="h-1.5 w-24 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
                <!-- Testimonial 1 -->
                <div class="bg-white p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="absolute -top-12 left-1/2 transform -translate-x-1/2">
                            <div class="w-24 h-24 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full p-1">
                                <div class="w-full h-full bg-white rounded-full flex items-center justify-center">
                                    <span class="text-3xl font-bold text-blue-600">সা</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center pt-6">
                        <h4 class="text-xl font-bold text-gray-800 mb-2">সাদিয়া আহমেদ</h4>
                        <p class="text-blue-600 font-medium mb-4">৮ম শ্রেণী</p>
                        <div class="flex justify-center text-yellow-400 mb-6">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-gray-600 leading-relaxed italic">"কুইজ মাফিয়া আমার পড়াশোনায় সাহায্য করেছে। AI-জেনারেটেড প্রশ্নগুলি আমার দুর্বলতাগুলি খুঁজে বের করতে সাহায্য করেছে।"</p>
                    </div>
                </div>

                <!-- Testimonial 2 -->
                <div class="bg-white p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="absolute -top-12 left-1/2 transform -translate-x-1/2">
                            <div class="w-24 h-24 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full p-1">
                                <div class="w-full h-full bg-white rounded-full flex items-center justify-center">
                                    <span class="text-3xl font-bold text-purple-600">রা</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center pt-6">
                        <h4 class="text-xl font-bold text-gray-800 mb-2">রাফি হোসেন</h4>
                        <p class="text-purple-600 font-medium mb-4">৯ম শ্রেণী</p>
                        <div class="flex justify-center text-yellow-400 mb-6">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                        <p class="text-gray-600 leading-relaxed italic">"এই অ্যাপটি ব্যবহার করে আমার বিজ্ঞান বিষয়ে অনেক উন্নতি হয়েছে। প্রতিদিন কুইজ সমাধান করার মাধ্যমে আমার পরীক্ষার প্রস্তুতি সহজ হয়েছে।"</p>
                    </div>
                </div>

                <!-- Testimonial 3 -->
                <div class="bg-white p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="absolute -top-12 left-1/2 transform -translate-x-1/2">
                            <div class="w-24 h-24 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full p-1">
                                <div class="w-full h-full bg-white rounded-full flex items-center justify-center">
                                    <span class="text-3xl font-bold text-pink-600">তা</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center pt-6">
                        <h4 class="text-xl font-bold text-gray-800 mb-2">তাসনিম ইসলাম</h4>
                        <p class="text-pink-600 font-medium mb-4">১০ম শ্রেণী</p>
                        <div class="flex justify-center text-yellow-400 mb-6">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-gray-600 leading-relaxed italic">"লিডারবোর্ডে নিজের নাম দেখার জন্য প্রতিযোগিতা করতে ভালো লাগে। এই অ্যাপের মাধ্যমে আমি পড়াশোনাকে একটি মজার খেলায় পরিণত করতে পেরেছি।"</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <?php include"./components/footer.php"; ?>

    <script>
        // Typing Animation
        const text = "আপনার জ্ঞান পরীক্ষা করুন, লিডারবোর্ডে উঠুন এবং হোন সর্বশ্রেষ্ঠ কুইজ মাস্টার!";
        let index = 0;
        const typewriterElement = document.getElementById("typewriter");
        
        function typeWriter() {
            if (index < text.length) {
                typewriterElement.innerHTML += text.charAt(index);
                index++;
                setTimeout(typeWriter, 50);
            } else {
                typewriterElement.style.borderRight = "none";
            }
        }

        // Mobile Menu Toggle
        

        // Smooth Scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Start animation
        window.onload = function() {
            typeWriter();
        }
    </script>
</body>
</html>