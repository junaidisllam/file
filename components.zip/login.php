<?php
require 'db/db.php';

// Set session cookie parameters for 5 years
$lifetime = 60 * 60 * 24 * 365 * 5; // 5 years in seconds
session_set_cookie_params($lifetime, '/');
session_start();

header('Content-Type: application/json');

$response = ['success' => false, 'errors' => []];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $remember_me = isset($_POST['remember_me']); // Check if "Remember Me" is checked

    // Validation
    if (empty($phone)) {
        $response['errors']['phone'] = 'Phone number is required';
    }

    if (empty($password)) {
        $response['errors']['password'] = 'Password is required';
    }

    if (empty($response['errors'])) {
        // Fetch user from database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Login successful
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_phone'] = $user['phone'];
            $_SESSION['full_name'] = $user['full_name'];

            // Set "Remember Me" cookie if checked
            if ($remember_me) {
                $token = bin2hex(random_bytes(32)); // Generate a secure token
                $expires = date('Y-m-d H:i:s', time() + $lifetime); // 5 years from now

                // Store token in database
                $stmt = $pdo->prepare("INSERT INTO user_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
                $stmt->execute([$user['id'], $token, $expires]);

                // Set cookie
                setcookie('remember_me', $token, time() + $lifetime, '/', '', true, true); // Secure and HttpOnly
            }

            $response['success'] = true;
        } else {
            $response['errors']['login'] = 'Invalid phone number or password';
        }
    }
}

echo json_encode($response);
?>