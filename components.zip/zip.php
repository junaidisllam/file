<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if ZIP extension is enabled
    if (!extension_loaded('zip')) {
        die("❌ ZIP extension is not enabled. Please contact your server administrator.");
    }

    // Check if files were uploaded
    if (empty($_FILES['files']['name'][0])) {
        die("❌ No files selected. Please choose a folder to convert.");
    }

    // Create temporary ZIP file
    $temp_file = tempnam(sys_get_temp_dir(), 'zip_') . '.zip';
    $zip = new ZipArchive();

    if ($zip->open($temp_file, ZipArchive::CREATE) !== TRUE) {
        die("❌ Failed to create ZIP archive.");
    }

    // Add files to ZIP archive
    foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['files']['error'][$key] === UPLOAD_ERR_OK) {
            $file_name = $_FILES['files']['name'][$key];
            $zip->addFile($tmp_name, $file_name);
        }
    }

    $zip->close();

    // Send ZIP file for download
    header("Content-Type: application/zip");
    header("Content-Disposition: attachment; filename=folder.zip");
    header("Content-Length: " . filesize($temp_file));
    readfile($temp_file);

    // Clean up temporary file
    unlink($temp_file);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Folder to ZIP Converter</title>
</head>
<body>
    <h1>📁 Folder to ZIP Converter</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="files[]" id="files" webkitdirectory directory multiple>
        <button type="submit">Convert to ZIP</button>
    </form>
    <p>✅ Select a folder and click "Convert to ZIP". The ZIP file will be downloaded automatically.</p>
</body>
</html>
