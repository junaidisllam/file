<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI tools</title>
    <!-- Add Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Add Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include "./components/navbar.php" ?>
    <!-- AI Tools Section -->
    <section id="ai-tools" class="py-10 bg-gradient-to-b from-white to-blue-50">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <span class="text-blue-600 font-semibold text-sm tracking-wider uppercase mb-2 inline-block">AI টুলস</span>
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">আমাদের <span class="text-blue-600">AI টুলস</span></h2>
                <p class="text-gray-600 text-lg leading-relaxed">আধুনিক AI প্রযুক্তি ব্যবহার করে আপনার শিক্ষা যাত্রাকে করে তুলুন আরও সহজ</p>
                <div class="h-1.5 w-24 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
                <!-- Math Master -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-calculator text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-blue-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">ম্যাথ মাস্টার</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">গণিতের সমস্যা সমাধান এবং ধাপে ধাপে সমাধান প্রক্রিয়া দেখুন</p>
                    <button disabled class="inline-block bg-gray-400 text-white font-bold py-3 px-6 rounded-lg shadow-lg cursor-not-allowed">
                        <i class="fas fa-clock mr-2"></i>
                        খুব শীঘ্রই আসছে
                    </button>
                </div>

                <!-- English Master -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-50">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-language text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-green-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">ইংলিশ মাস্টার</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">ইংরেজি ভাষা শিখুন এবং অনুবাদ করুন AI এর সাহায্যে</p>
                    <button disabled class="inline-block bg-gray-400 text-white font-bold py-3 px-6 rounded-lg shadow-lg cursor-not-allowed">
                        <i class="fas fa-clock mr-2"></i>
                        খুব শীঘ্রই আসছে
                    </button>
                </div>

                <!-- Coming Soon -->
                <div class="group bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-gray-100">
                    <div class="relative mb-8">
                        <div class="w-20 h-20 bg-gradient-to-br from-gray-400 to-gray-600 rounded-2xl flex items-center justify-center transform group-hover:rotate-6 transition-transform duration-300">
                            <i class="fas fa-clock text-4xl text-white group-hover:scale-110 transition-transform duration-300"></i>
                        </div>
                        <div class="absolute -bottom-4 -right-4 w-20 h-20 bg-gray-100 rounded-full opacity-50 group-hover:scale-110 transition-transform duration-300"></div>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">আরও আসছে...</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">নতুন AI টুলস খুব শীঘ্রই যুক্ত হবে</p>
                    <button disabled class="inline-block bg-gray-400 text-white font-bold py-3 px-6 rounded-lg shadow-lg cursor-not-allowed">
                        <i class="fas fa-clock mr-2"></i>
                        অপেক্ষায় থাকুন
                    </button>
                </div>
            </div>
        </div>
    </section>
    <?php include "./components/footer.php" ?>

</body>
</html>