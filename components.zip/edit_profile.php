<?php
require 'db/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $school = $_POST['school'];
    $class = $_POST['class'];
    $section = $_POST['section'];
    $address = $_POST['address'];

    if (!empty($_FILES['profile_pic']['name'])) {
        $file = $_FILES['profile_pic'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $ext;
        
        if (move_uploaded_file($file['tmp_name'], 'uploads/' . $filename)) {
            // Resize image
            $source_path = 'uploads/' . $filename;
            $image_info = getimagesize($source_path);
            $width = 300;
            $height = round(($width / $image_info[0]) * $image_info[1]);
            
            $source = imagecreatefromstring(file_get_contents($source_path));
            $destination = imagecreatetruecolor($width, $height);
            
            imagecopyresampled($destination, $source, 0, 0, 0, 0, $width, $height, $image_info[0], $image_info[1]);
            
            switch ($ext) {
                case 'jpg':
                case 'jpeg':
                    imagejpeg($destination, $source_path, 90);
                    break;
                case 'png':
                    imagepng($destination, $source_path, 9);
                    break;
                case 'gif':
                    imagegif($destination, $source_path);
                    break;
            }
            
            imagedestroy($source);
            imagedestroy($destination);

            if (!empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic'])) {
                unlink('uploads/' . $user['profile_pic']);
            }
            $stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
            $stmt->execute([$filename, $_SESSION['user_id']]);
        }
    }

    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, school = ?, class = ?, section = ?, address = ? WHERE id = ?");
    $stmt->execute([$full_name, $email, $phone, $school, $class, $section, $address, $_SESSION['user_id']]);

    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 min-h-screen">
    <?php include "./components/navbar.php" ?>
        <div class="container mx-auto px-4 py-8 pt-28">
            <div class="max-w-2xl mx-auto bg-white rounded-xl shadow-2xl p-8">
                <div class="flex items-center mb-8">
                    <i class="fas fa-user-edit text-3xl text-blue-500 mr-4"></i>
                    <h2 class="text-3xl font-bold text-gray-800">Edit Profile</h2>
                </div>
                
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-8">
                        <label class="block text-gray-700 text-lg font-semibold mb-4">Profile Picture</label>
                        <div class="flex items-center space-x-6">
                            <div class="relative">
                                <?php if (!empty($user['profile_pic'])): ?>
                                    <img src="uploads/<?= htmlspecialchars($user['profile_pic']) ?>" 
                                         class="w-32 h-32 rounded-full object-cover border-4 border-blue-500 shadow-xl">
                                    <div class="absolute -top-2 -right-2 bg-blue-500 rounded-full p-2 shadow-lg">
                                        <i class="fas fa-camera text-white"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="relative group flex-1 max-w-sm">
                                <div class="flex items-center justify-center w-full h-40 border-3 border-dashed border-blue-200 rounded-xl 
                                            bg-gradient-to-br from-blue-50 to-gray-50 hover:from-blue-100 hover:to-white
                                            transition-all duration-300 ease-in-out transform hover:scale-105">
                                    <input type="file" name="profile_pic" accept="image/*" 
                                           class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                    <div class="flex flex-col items-center space-y-3">
                                        <div class="p-4 rounded-full bg-blue-100 group-hover:bg-blue-200 transition-colors">
                                            <i class="fas fa-cloud-upload-alt text-4xl text-blue-500"></i>
                                        </div>
                                        <span class="text-lg font-medium text-blue-500">Upload New Photo</span>
                                        <p class="text-sm text-gray-500">PNG, JPG or GIF (MAX. 800x800px)</p>
                                    </div>
                                </div>
                                <div id="imagePreview" class="mt-4 hidden">
                                    <div class="relative inline-block">
                                        <img src="#" alt="Preview" class="w-40 h-40 object-cover rounded-xl shadow-lg">
                                        <button type="button" id="removePreview" 
                                                class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-2 shadow-lg
                                                       hover:bg-red-600 transition-colors">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        const fileInput = document.querySelector('input[type="file"]');
                        const imagePreview = document.querySelector('#imagePreview');
                        const previewImg = imagePreview.querySelector('img');
                        const removeButton = document.querySelector('#removePreview');

                        fileInput.addEventListener('change', function(e) {
                            if (e.target.files && e.target.files[0]) {
                                const reader = new FileReader();
                                reader.onload = function(e) {
                                    previewImg.src = e.target.result;
                                    imagePreview.classList.remove('hidden');
                                }
                                reader.readAsDataURL(e.target.files[0]);
                            }
                        });

                        removeButton.addEventListener('click', function() {
                            fileInput.value = '';
                            imagePreview.classList.add('hidden');
                        });
                    </script>

                    <div class="grid md:grid-cols-2 gap-6">
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-semibold mb-2">Full Name</label>
                            <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-semibold mb-2">Email</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        </div>
                    </div>

                    <div class="grid md:grid-cols-2 gap-6">
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-semibold mb-2">Phone</label>
                            <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-semibold mb-2">School</label>
                            <input type="text" name="school" list="schools" value="<?= htmlspecialchars($user['school']) ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <datalist id="schools">
                                <!-- Previous school options remain the same -->
                                <?php include 'school_list.php'; // Move schools to separate file for cleaner code ?>
                            </datalist>
                        </div>
                    </div>

                    <div class="grid md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <label class="block text-gray-700 text-sm font-semibold mb-2">Class</label>
                            <input type="text" name="class" value="<?= htmlspecialchars($user['class']) ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        </div>
                        <div>
                            <label class="block text-gray-700 text-sm font-semibold mb-2">Section</label>
                            <input type="text" name="section" value="<?= htmlspecialchars($user['section']) ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        </div>
                    </div>

                    <div class="mb-8">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Address</label>
                        <textarea name="address" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition min-h-[100px]"><?= htmlspecialchars($user['address']) ?></textarea>
                    </div>

                    <div class="flex justify-end gap-4">
                        <a href="dashboard.php" class="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition duration-200 ease-in-out font-medium">Cancel</a>
                        <button type="submit" class="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-200 ease-in-out font-medium shadow-lg hover:shadow-xl">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
</body>
</html>