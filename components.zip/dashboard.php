<?php
require 'db/db.php';
session_set_cookie_params(60 * 60 * 24 * 365 * 5, '/');
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /register");
    exit();
  }
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_phone'] = $user['phone'];
        $_SESSION['full_name'] = $user['full_name'];
    } else {
        session_destroy();
        setcookie('remember_me', '', time() - 3600, '/');
    }
    $stmt = $pdo->prepare("SELECT SUM(score) as total_score FROM user_scores WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id'] ?? 0]);
$scoreData = $stmt->fetch();
$totalScore = $scoreData['total_score'] ?? 0;

$stmt = $pdo->prepare("
    SELECT rank 
    FROM (
        SELECT user_id, DENSE_RANK() OVER (ORDER BY total_score DESC) as rank
        FROM (
            SELECT user_id, SUM(score) as total_score 
            FROM user_scores 
            GROUP BY user_id
        ) scores
    ) rankings 
    WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id'] ?? 0]);
$rankData = $stmt->fetch();
$userRank = $rankData['rank'] ?? 'N/A';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 min-h-screen">
    <?php include "./components/navbar.php" ?>   
    <section class="py-12 md:py-24 bg-gradient-to-b from-white to-blue-50 max-sm:pt-20">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden">
                <div class="bg-gradient-to-r from-blue-500 to-blue-600 p-4 md:p-8 text-center">
                    <div class="relative inline-block">
                        <div class="w-24 h-24 md:w-32 md:h-32 bg-white rounded-full p-2 mx-auto">
                            <img class="w-full h-full rounded-full object-cover" 
                                 src="<?= !empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic']) ? 'uploads/' . htmlspecialchars($user['profile_pic']) : 'https://avatar.iran.liara.run/username?username=' . urlencode($user['full_name']) ?>" 
                                 alt="Profile Picture">
                        </div>
                        <a href="edit_profile.php" class="absolute bottom-0 right-0 bg-white p-1.5 md:p-2 rounded-full shadow-lg hover:bg-gray-100">
                            <i class="fas fa-camera text-sm md:text-base text-blue-500"></i>
                        </a>
                    </div>
                    <h2 class="text-xl md:text-2xl font-bold text-white mt-4"><?= htmlspecialchars($user['full_name']) ?></h2>
                    <p class="text-sm md:text-base text-blue-100"><?= htmlspecialchars($user['phone']) ?></p>
                </div>

                <div class="p-4 md:p-8">
                    <!-- Stats Grid -->
                    <div class="grid grid-cols-2 gap-3 md:gap-6 mb-6 md:mb-8">
                        <div class="bg-blue-50 p-2 md:p-4 rounded-2xl text-center">
                            <div class="text-xl md:text-3xl font-bold text-blue-600 mb-1"><?= number_format($totalScore) ?></div>
                            <div class="text-xs md:text-sm text-gray-600">মোট স্কোর</div>
                        </div>
                        <div class="bg-purple-50 p-2 md:p-4 rounded-2xl text-center">
                            <div class="text-xl md:text-3xl font-bold text-purple-600 mb-1">#<?= $userRank ?></div>
                            <div class="text-xs md:text-sm text-gray-600">র‍্যাঙ্কিং</div>
                        </div>
                    </div>

                    <!-- Class Information -->
                    <div class="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-2xl mb-6 md:mb-8">
                        <h3 class="text-lg font-bold text-green-700 mb-3">আমার ক্লাস</h3>
                        <div class="grid grid-cols-2 gap-3">
                            <div class="bg-white p-3 rounded-xl shadow-sm">
                                <div class="text-sm text-gray-500">বর্তমান ক্লাস</div>
                                <div class="text-lg font-bold text-green-600"><?= htmlspecialchars($user['class'] ?? 'Not set') ?></div>
                            </div>
                            <div class="bg-white p-3 rounded-xl shadow-sm">
                                <div class="text-sm text-gray-500">শাখা</div>
                                <div class="text-lg font-bold text-green-600"><?= htmlspecialchars($user['section'] ?? 'Not set') ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Profile Details -->
                    <div class="space-y-4 md:space-y-6">
                        <div class="flex items-center p-3 md:p-4 bg-gray-50 rounded-2xl">
                            <i class="fas fa-envelope w-6 md:w-8 text-blue-500 text-sm md:text-base"></i>
                            <div class="ml-3 md:ml-4">
                                <div class="text-xs md:text-sm text-gray-500 font-solaimanlipi">ইমেইল</div>
                                <div class="text-sm md:text-base font-medium"><?= htmlspecialchars($user['email'] ?? 'Not set') ?></div>
                            </div>
                        </div>
                        <div class="flex items-center p-3 md:p-4 bg-gray-50 rounded-2xl">
                            <i class="fas fa-school w-6 md:w-8 text-green-500 text-sm md:text-base"></i>
                            <div class="ml-3 md:ml-4">
                                <div class="text-xs md:text-sm text-gray-500 font-solaimanlipi">স্কুল</div>
                                <div class="text-sm md:text-base font-medium"><?= htmlspecialchars($user['school'] ?? 'Not set') ?></div>
                            </div>
                        </div>
                        <div class="flex items-center p-3 md:p-4 bg-gray-50 rounded-2xl">
                            <i class="fas fa-location-dot w-6 md:w-8 text-purple-500 text-sm md:text-base"></i>
                            <div class="ml-3 md:ml-4">
                                <div class="text-xs md:text-sm text-gray-500 font-solaimanlipi">ঠিকানা</div>
                                <div class="text-sm md:text-base font-medium"><?= htmlspecialchars($user['address'] ?? 'Not set') ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex flex-col sm:flex-row gap-3 md:gap-4 mt-6 md:mt-8">
                        <a href="edit_profile.php" class="flex-1 bg-blue-500 text-white py-2 md:py-3 px-4 md:px-6 rounded-xl hover:bg-blue-600 transition-colors text-sm md:text-base text-center">
                            <i class="fas fa-edit mr-2"></i>প্রোফাইল এডিট
                        </a>
                        <a href="logout.php" class="flex-1 border-2 border-red-500 text-red-500 py-2 md:py-3 px-4 md:px-6 rounded-xl hover:bg-red-50 transition-colors text-sm md:text-base text-center">
                            <i class="fas fa-sign-out-alt mr-2"></i>লগআউট
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>


