<?php

// Start session to access user data
session_start();

// Check if the user is logged in (user_id exists in session)
if (!isset($_SESSION['user_id'])) {
  header("Location: /register");
  exit();
}

$userId = $_SESSION['user_id'];

// Include database connection
include('db/db.php');

// Prepare SQL statement to get the user's score
$stmt = $connection->prepare("SELECT score FROM user_scores WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $score = $row['score'];
} else {
  $score = 0;
}

$stmt->close();
$connection->close();

$class = isset($_GET['class']) ? $_GET['class'] : '';
$subject = isset($_GET['subject']) ? $_GET['subject'] : '';

?>
<?php
include __DIR__ . '/booksdata.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>AI-Powered Quiz Generator</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
    }
    
    @keyframes pop-in {
      0% { transform: scale(0.5); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }

    .animate-pop-in {
      animation: pop-in 0.3s ease-out;
    }
    
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #6366f1;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @keyframes slide-down {
      0% { transform: translateY(-50px); opacity: 0; }
      100% { transform: translateY(0); opacity: 1; }
    }

    .animate-slide-down {
      animation: slide-down 0.5s ease-out;
    }
  </style>
</head>
<body class="bg-gradient-to-br from-purple-600 via-blue-500 to-pink-500 min-h-screen flex items-center justify-center sm:p-4">
<button onclick="history.back()" class="max-sm:opacity-40 max-sm:hover:opacity-90 absolute top-4 left-4 bg-white p-2 rounded-lg shadow-md hover:shadow-lg transition-shadow z-50">
  <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
  </svg>
</button>
<div class="container mx-auto sm:max-w-[95%] p-2 sm:p-8 bg-white sm:rounded-2xl shadow-2xl backdrop-blur-lg h-screen sm:h-[90vh] max-sm:overflow-hidden">
    
    <!-- Chapter Selection -->
    <div id="chapterSelection" class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div class="max-sm:text-center pt-5">
          <h3 class="text-2xl font-bold text-gray-800">Select Chapters</h3>
          <p class="text-gray-600">Choose at least 1 chapter to start</p>
        </div>
        <div class="flex items-center gap-3 bg-purple-100 px-4 py-2 rounded-full">
          <span class="text-purple-600 font-bold text-lg" id="selectedCount">0</span>
          <span class="text-gray-600">selected</span>
        </div>
      </div>
      
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 overflow-y-auto max-h-[25rem] p-2">
        <!-- Dynamic Chapters -->
      </div>
      <div class="flex flex-row gap-4 mt-6 max-w-3xl mx-auto">
        <button id="selectAllBtn" class="flex-1 px-6 py-4 bg-white hover:bg-purple-50 border-2 border-gray-200 rounded-xl transition-all duration-300 shadow-sm hover:shadow-md flex items-center justify-center gap-2 group">
          <svg class="w-5 h-5 text-purple-500 group-hover:scale-110 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5h16M4 12h16m-7 7h7" />
          </svg>
          <span class="font-medium text-gray-700 group-hover:text-purple-600 transition-colors duration-300">Select All Chapters</span>
        </button>
        
        <button id="startQuizBtn" disabled class="flex-1 px-6 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
          <svg class="w-6 h-6 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>Start Quiz</span>
          <span class="flex items-center justify-center bg-white/20 rounded-full h-7 w-7 font-bold text-sm" id="selectedCountBtn">0</span>
        </button>
      </div>
        </div>

    <!-- Loading State -->
    <div id="loading" class="hidden text-center py-12 flex flex-col items-center justify-center relative h-full">
      <div class="animate-pulse flex flex-col items-center justify-center space-y-6">
      <div class="relative">
        <img src="/ai.gif" alt="AI" class="w-24 h-24 rounded-full shadow-lg" style="filter: hue-rotate(60deg)" />
      </div>
      
      <div class="space-y-3">
        <h3 class="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">
        Generating Your Quiz
        </h3>
        <div class="flex flex-col items-center space-y-2">
        <p class="text-gray-600">Creating challenging questions for you...</p>
        <div class="flex space-x-2">
          <div class="w-2 h-2 bg-purple-600 rounded-full animate-bounce"></div>
          <div class="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
          <div class="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
        </div>
        </div>
      </div>
      </div>
    </div>
    <!-- Quiz Container -->
    <div id="quizContainer" class="hidden">
      <div class="flex flex-col md:flex-row justify-between items-center mb-8 gap-4 max-sm:mt-4">
        <div class="flex items-center gap-4">
          <button id="pauseBtn" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg hidden">
            ⏸️ Pause
          </button>
          <div class="flex items-center gap-2 bg-purple-100 px-4 py-2 rounded-full shadow-sm">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-purple-600 animate-spin-slow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span id="timer" class="font-mono text-lg font-bold text-purple-600">00:00</span>
          </div>

          <style>
          @keyframes spin-slow {
            from {
              transform: rotate(0deg);
            }
            to {
              transform: rotate(360deg);
            }
          }

          .animate-spin-slow {
            animation: spin-slow 3s linear infinite;
          }
          </style>
        </div>
        <div class="flex items-center gap-4">
          <!-- Streak Counter -->
          <div class="flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full">
            <svg class="w-5 h-5 text-orange-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M16.5 8c0 1.5-.5 3.5-2.9 4.3.7-1.7.8-3.4.3-5-.7-2.1-3-3.7-4.6-4.6-.4-.3-1.1.1-1 .7 0 1.1-.3 2.7-2 4.4C4.1 10 3 12.3 3 14.5 3 17.4 5 21 9 21c-4-4-1-7.5-1-7.5.8 5.9 5 7.5 7 7.5 1.7 0 5-1.2 5-6.4 0-3.1-1.3-5.5-2.4-6.9-.3-.5-1-.2-1.1.3"/>
            </svg>
            <div class="flex items-center">
              <span class="text-sm font-medium text-orange-700">Streak:</span>
              <span id="streak" class="ml-1 text-lg font-bold text-orange-600">0</span>
            </div>
          </div>

          <!-- Score Counter -->
          <div class="flex items-center gap-2 px-4 py-2 bg-purple-100 rounded-full">
            <svg class="w-5 h-5 text-purple-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M21 4h-3V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v1H3a1 1 0 0 0-1 1v3c0 4.31 1.799 6.91 4.819 7.012A6.001 6.001 0 0 0 11 17.91V20H9v2h6v-2h-2v-2.09a6.01 6.01 0 0 0 4.181-2.898C20.201 14.91 22 12.31 22 8V5a1 1 0 0 0-1-1zM4 8V6h2v6.83C4.216 12.078 4 9.299 4 8zm8 8c-2.206 0-4-1.794-4-4V4h8v8c0 2.206-1.794 4-4 4zm6-3.17V6h2v2c0 1.299-.216 4.078-2 4.83z"/>
            </svg>
            <div class="flex items-center">
              <span class="text-sm font-medium text-purple-700">Score:</span>
              <span id="score" class="ml-1 text-lg font-bold text-purple-600">0</span>
              <span class="mx-1 text-purple-600">/</span>
              <span id="maxScore" class="text-lg font-bold text-purple-600">0</span>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Progress Bar -->
      <div class="mb-6">
        <div class="h-3 bg-gray-200 rounded-full shadow-inner">
          <div id="progressBar" class="h-3 bg-gradient-to-r from-purple-500 to-blue-400 rounded-full transition-all duration-500" style="width: 0%"></div>
        </div>
      </div>
      <style>
         :root {
      --math-primary: #1a1a1a;
      --math-accent: #2b5797;
      --math-border: #7f7f7f;
    }

    /* Derivative-like fraction styling */
    .derivative {
      display: inline-flex;
      flex-direction: column;
      align-items: center;
      margin: 0 0.25em;
      vertical-align: middle;
      position: relative;
      transform: translateY(5%);
      line-height: 1;
    }

    .numerator {
      font-size: 0.85em;
      border-bottom: 1px solid var(--math-border);
      padding: 0 0.1em;
      letter-spacing: 0.05em;
    }

    .denominator {
      font-size: 0.85em;
      padding-top: 0.1em;
      color: var(--math-accent);
    }
      </style>
      <!-- Question Card -->
      <div id="questionCard" class="bg-white sm:shadow-lg sm:p-6 sm:rounded-2xl sm:mb-6 sm:border-2 sm:border-purple-100 animate-pop-in">
        <div class="flex items-center gap-2 mb-4 text-purple-600">
          <span class="text-sm font-semibold">Question Type:</span>
          <span id="questionType" class="bg-purple-100 px-3 py-1 rounded-full text-sm">Multiple Choice</span>
        </div>
        <h2 id="questionText" class="text-base lg:text-2xl md:text-lg font-bold mb-6 text-gray-800"></h2>
        
        <div id="options" class="grid gap-3"></div>
      </div>
      
      <!-- Navigation -->
      <div class="flex flex-col sm:flex-row justify-between gap-4">
        <div class="flex gap-4">
          <button id="flagBtn" class="px-4 py-2 bg-yellow-100 hover:bg-yellow-200 text-yellow-800 rounded-lg hidden">
            ⚑ Flag Question
          </button>
        </div>
        <div class="flex gap-4">
          <!-- <button id="prevBtn" class="px-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition transform hover:scale-105">
            ← Previous
          </button> -->
          <button id="nextBtn" class="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition transform hover:scale-105 max-sm:w-full max-sm:fixed max-sm:bottom-5 max-sm:max-w-[95%] max-sm:m-auto  max-sm:z-50">
            Next →
          </button>
        </div>
      </div>
    </div>
    
    <!-- Results Screen -->
    <div id="results" class="hidden text-center py-12">
      <div class="animate-bounce mb-8 text-6xl flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100" height="100">
          <g><path fill="#e86752" d="m124.91 78.938 22.102 6.87 6.87 22.106a15.11 15.11 0 0 0 14.43 10.625c4.852 0 9.473-2.344 12.329-6.387l13.367-18.898 23.144.297h.196a15.1 15.1 0 0 0 12.102-24.137L215.604 50.86l7.434-21.922a15.102 15.102 0 0 0-19.156-19.152L181.96 17.22 163.414 3.37A15.115 15.115 0 0 0 147.52 2.02a15.113 15.113 0 0 0-8.247 13.652l.297 23.144-18.898 13.368a15.1 15.1 0 0 0 4.238 26.754zm38.586-20.04a15.111 15.111 0 0 0 6.383-12.527l-.008-.48.39.285a15.102 15.102 0 0 0 13.884 2.203l.457-.156-.153.457a15.095 15.095 0 0 0 2.2 13.886l.288.387-.484-.008h-.195a15.108 15.108 0 0 0-12.328 6.383l-.282.395-.14-.461a15.103 15.103 0 0 0-9.942-9.938l-.464-.144zm0 0" opacity="1" data-original="#e86752" class=""></path><path fill="#e86752" d="M219.45 109.965c-3.536-7.559-12.544-10.844-20.098-7.309-7.555 3.54-10.825 12.5-7.29 20.055 1.141 2.492 27.215 61.434-31.468 98.43-7.055 4.449-9.168 13.773-4.719 20.832 2.871 4.554 7.777 7.05 12.79 7.05 2.753 0 5.538-.753 8.042-2.328 42.465-26.773 51.875-62.703 52.29-88.129.437-26.96-9.138-47.734-9.548-48.601zm0 0" opacity="1" data-original="#e86752" class=""></path><path fill="#e35336" d="m490.344 325.598 7.433-21.922a15.107 15.107 0 0 0-3.62-15.531 15.109 15.109 0 0 0-15.532-3.625l-21.922 7.433-18.555-13.844a15.104 15.104 0 0 0-24.137 12.297l.298 23.149-18.899 13.363a15.109 15.109 0 0 0-6.2 14.695 15.112 15.112 0 0 0 10.435 12.063l22.105 6.87 6.871 22.106a15.11 15.11 0 0 0 12.063 10.438 15.113 15.113 0 0 0 14.695-6.2l13.363-18.898 23.149.293a15.094 15.094 0 0 0 13.652-8.242 15.107 15.107 0 0 0-1.355-15.895zm-29.153 12.086a15.08 15.08 0 0 0-12.527 6.382l-.277.395-.145-.461a15.109 15.109 0 0 0-9.941-9.941l-.461-.145.394-.277a15.111 15.111 0 0 0 6.383-12.528l-.004-.48.387.289a15.112 15.112 0 0 0 13.883 2.2l.46-.157-.155.457a15.095 15.095 0 0 0 2.199 13.887l.289.386zm0 0" opacity="1" data-original="#e35336" class=""></path><path fill="#e35336" d="M384.844 315.496c7.543 3.496 16.504.238 20.031-7.3 3.54-7.555.281-16.548-7.277-20.083-.871-.41-21.692-9.992-48.602-9.543-25.426.41-61.355 9.817-88.129 52.285-4.449 7.06-2.332 16.387 4.723 20.833a15.025 15.025 0 0 0 8.039 2.332c5.016 0 9.922-2.497 12.793-7.051 36.957-58.621 95.816-32.66 98.422-31.473zm0 0" opacity="1" data-original="#e35336" class=""></path><path fill="#fecb5b" d="M164.43 161.355a15.09 15.09 0 0 0-5.493-11.648l-35.367-29.184a15.105 15.105 0 0 0-19.226 0l-35.367 29.184a15.103 15.103 0 0 0 0 23.3l35.367 29.18a15.075 15.075 0 0 0 9.613 3.458c3.41 0 6.824-1.153 9.613-3.458l35.368-29.18a15.097 15.097 0 0 0 5.492-11.652zm-50.473 9.602-11.637-9.602 11.637-9.597 11.637 9.597zm0 0" opacity="1" data-original="#fecb5b" class=""></path><path fill="#42b893" d="m506.508 200.082-35.367-29.184a15.105 15.105 0 0 0-19.227 0l-35.371 29.184a15.102 15.102 0 0 0 0 23.3l35.371 29.18a15.06 15.06 0 0 0 9.613 3.458c3.41 0 6.82-1.153 9.614-3.458l35.367-29.18a15.103 15.103 0 0 0 0-23.3zm-44.98 21.25-11.637-9.602 11.636-9.601 11.637 9.601zm0 0" opacity="1" data-original="#42b893"></path><path fill="#4398cf" d="M238.52 260.23c1.94-8.207 6.738-16.457 13.507-23.222 0-.004 0-.004.004-.004 2.844-2.844 6.336-5.774 9.965-8.445 2.129 8.324 6.285 15.785 12.336 21.836 8.211 8.214 20.02 13.59 31.45 13.59 8.085 0 15.988-2.696 22.277-8.985 15.171-15.172 9.421-39.703-4.602-53.727-6.25-6.246-14-10.476-22.656-12.535a55.594 55.594 0 0 1 3.898-4.386c2.7-2.61 5.895-5.262 9.211-7.707 2.13 8.328 6.281 15.789 12.332 21.84 6.602 6.6 15.52 11.304 24.465 12.906 2.297.41 4.57.613 6.793.613 8.707 0 16.656-3.102 22.469-8.918 15.172-15.168 9.426-39.7-4.602-53.727-6.246-6.246-13.996-10.472-22.652-12.535a56.308 56.308 0 0 1 4.215-4.722c.004 0 .004 0 .004-.004 2.843-2.844 6.343-5.774 9.972-8.45 2.125 8.329 6.281 15.79 12.336 21.84 6.602 6.602 15.516 11.305 24.461 12.903a38.26 38.26 0 0 0 6.793.613c8.707 0 16.656-3.102 22.469-8.914 7.297-7.297 10.324-17.961 8.3-29.266-1.597-8.941-6.3-17.86-12.902-24.46-6.246-6.247-14-10.473-22.652-12.536a56.308 56.308 0 0 1 4.215-4.723c.004 0 .004-.003.004-.003 6.765-6.766 15.011-11.563 23.222-13.504 9.059-2.145 17.008-.621 21.801 4.172a15.061 15.061 0 0 0 10.68 4.425c3.867 0 7.734-1.472 10.68-4.425 5.902-5.899 5.902-15.461 0-21.36-12.368-12.367-30.633-16.82-50.114-12.215-13.785 3.262-26.8 10.711-37.633 21.543 0 .004-.003.004-.003.008-8.645 8.645-15.133 18.68-19.06 29.387-13.19 5.715-26.843 16.512-33.933 23.601 0 .004-.004.008-.004.008-8.644 8.645-15.136 18.68-19.058 29.387-12.317 5.34-25.035 15.105-32.438 22.148-.136.125-.28.239-.414.371-.172.172-.34.352-.511.524-.188.187-.391.379-.57.558-.126.13-.235.266-.356.395-7.93 8.305-13.922 17.813-17.625 27.918-13.184 5.71-26.836 16.504-33.922 23.594-.004.004-.008.004-.008.008-10.832 10.832-18.281 23.843-21.547 37.632v.004c-4.605 19.477-.152 37.742 12.215 50.11a15.061 15.061 0 0 0 10.68 4.425c3.867 0 7.734-1.476 10.68-4.425 5.898-5.899 5.898-15.461 0-21.36-4.794-4.797-6.317-12.742-4.176-21.8zm168.484-142.503c4.031 4.03 5.117 9.425 4.578 10.976-1.55.543-6.945-.543-10.98-4.574-2.836-2.84-4.528-6.777-4.993-11.395 4.618.461 8.555 2.153 11.395 4.993zm-52.996 52.992c4.031 4.035 5.117 9.43 4.578 10.98-1.55.543-6.945-.543-10.98-4.578-2.836-2.836-4.528-6.773-4.993-11.394 4.617.464 8.555 2.156 11.395 4.992zm-51.914 51.914c4.031 4.035 5.12 9.43 4.578 10.98-1.55.543-6.945-.547-10.98-4.578-2.837-2.836-4.528-6.777-4.993-11.394 4.621.464 8.559 2.156 11.395 4.992zm0 0" opacity="1" data-original="#4398cf" class=""></path><path fill="#81ccb8" d="M295.832 92.07c11.793 0 23.586-4.488 32.566-13.468 17.957-17.957 17.957-47.176 0-65.133-17.96-17.957-47.18-17.957-65.136 0s-17.957 47.176 0 65.133c8.98 8.98 20.773 13.468 32.57 13.468zm-11.207-57.242a15.814 15.814 0 0 1 11.207-4.633c4.055 0 8.117 1.547 11.203 4.633 6.18 6.18 6.18 16.234 0 22.414-6.176 6.176-16.23 6.18-22.41 0s-6.18-16.234 0-22.414zm0 0" opacity="1" data-original="#81ccb8" class=""></path><path fill="#f7b545" d="M313.637 361.04c-17.953 17.956-17.953 47.175 0 65.132 8.98 8.98 20.773 13.469 32.57 13.469 11.793 0 23.586-4.489 32.566-13.47 17.957-17.956 17.957-47.175 0-65.132-17.957-17.957-47.175-17.96-65.136 0zm43.773 43.772c-6.176 6.176-16.23 6.176-22.41 0-6.18-6.18-6.18-16.234 0-22.414s16.23-6.18 22.41 0a15.733 15.733 0 0 1 4.645 11.207c0 4.23-1.649 8.211-4.645 11.207zM277.457 376.918 130.645 230.105a15.107 15.107 0 0 0-24.625 4.872L1.164 486.648a15.1 15.1 0 0 0 3.262 16.489 15.087 15.087 0 0 0 16.488 3.261L272.582 401.54a15.109 15.109 0 0 0 9.012-11.012 15.106 15.106 0 0 0-4.137-13.609zm0 0" opacity="1" data-original="#f7b545" class=""></path><path fill="#fecb5b" d="M130.645 230.105a15.107 15.107 0 0 0-24.625 4.872L1.164 486.648a15.1 15.1 0 0 0 3.262 16.489L204.05 303.512zm0 0" opacity="1" data-original="#fecb5b" class=""></path><path fill="#e35336" d="m73.246 313.648-22.351 53.637L67.02 487.191l28.867-12.027-21.055-156.55a15.16 15.16 0 0 0-1.586-4.966zm0 0" opacity="1" data-original="#e35336" class=""></path><path fill="#e86752" d="m73.246 313.648-22.351 53.637 10.597 78.785 26.867-26.867-13.527-100.59a15.16 15.16 0 0 0-1.586-4.965zm0 0" opacity="1" data-original="#e86752" class=""></path><path fill="#e35336" d="M130.645 230.105a15.107 15.107 0 0 0-24.625 4.872l-3.743 8.988 29.102 216.41 28.867-12.027-29.312-217.95zm0 0" opacity="1" data-original="#e35336" class=""></path><path fill="#e86752" d="M130.645 230.105a15.107 15.107 0 0 0-24.625 4.872l-3.743 8.988 19.121 142.2 26.872-26.872-17.336-128.895zm0 0" opacity="1" data-original="#e86752" class=""></path><path fill="#e35336" d="m172.414 271.875 23.473 161.621 28.789-11.992-16.547-113.914zm0 0" opacity="1" data-original="#e35336" class=""></path><path fill="#e86752" d="m172.414 271.875 8.024 55.25 23.613-23.613zm0 0" opacity="1" data-original="#e86752" class=""></path></g>
        </svg>
      </div>
      <h2 class="text-3xl font-bold mb-4">Quiz Complete!</h2>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <!-- Results Display -->
        <div class="bg-green-100 p-4 rounded-xl shadow-sm">
          <div class="text-2xl font-bold text-green-600" id="correctAnswers">0</div>
          <div class="text-gray-600">Correct</div>
        </div>
        <div class="bg-red-100 p-4 rounded-xl shadow-sm">
          <div class="text-2xl font-bold text-red-600" id="wrongAnswers">0</div>
          <div class="text-gray-600">Wrong</div>
        </div>
        <div class="bg-blue-100 p-4 rounded-xl shadow-sm">
          <div class="text-2xl font-bold text-blue-600" id="timeTaken">0s</div>
          <div class="text-gray-600">Time</div>
        </div>
        <div class="bg-purple-100 p-4 rounded-xl shadow-sm">
          <div class="text-2xl font-bold text-purple-600" id="finalScore">0</div>
          <div class="text-gray-600">Score</div>
        </div>
      </div>
      <div class="flex justify-center gap-4">
        <button onclick="location.reload()" class="px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl transition transform hover:scale-105">
            <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Try Again
        </button>
      </div>
    </div>
  </div>

  <!-- Audio Elements for Sound Effects -->
  <audio id="correctSound" src="/rightans.mp3" preload="auto"></audio>
  <audio id="wrongSound" src="/wrongans.mp3" preload="auto"></audio>
  <audio id="completeSound" src="/complete.mp3" preload="auto"></audio>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      // Chapter List
    const chapters = <?php echo json_encode($chapters); ?>;

      let selectedChapters = [];
      let currentQuestion = 0;
      let score = 0;
      let quizData = [];
      let timer;
      let timeLeft;
      let totalTime;
      const timePerQuestion = 30; // 30 seconds per question
      let streakCounter = 0;

      // Initialize chapter selection
      const container = document.querySelector('#chapterSelection .grid');
      if (container) {
        chapters.forEach(chapter => {
            const button = document.createElement('button');
            button.className = 'group p-4 text-left rounded-xl bg-white sm:hover:bg-purple-50 border-2 border-gray-200 sm:hover:border-purple-400 transition-all duration-300 shadow-sm sm:hover:shadow-lg flex items-center justify-between sm:transform sm:hover:-translate-y-1';
            button.innerHTML = `
            <div class="flex items-center space-x-4">
            <div class="flex-shrink-0">
              <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-50 to-indigo-50 flex items-center justify-center sm:group-hover:from-purple-100 sm:group-hover:to-indigo-100 transition-all duration-300 sm:transform sm:group-hover:scale-110 shadow-sm sm:group-hover:shadow-md">
              <svg class="w-6 h-6 text-purple-500 sm:group-hover:text-purple-600 transform transition-all duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
              </div>
            </div>
            <div class="flex-1">
              <h3 class="font-semibold text-gray-800 sm:group-hover:text-purple-600 transition-colors duration-300 text-lg">${chapter}</h3>
              <p class="text-sm text-gray-500 sm:group-hover:text-purple-400 transition-colors duration-300">Click to select</p>
            </div>
            <div class="checkmark">
              <div class="w-8 h-8 rounded-lg bg-purple-50 sm:group-hover:bg-purple-100 flex items-center justify-center transition-all duration-300 opacity-0 transform scale-0">
              <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
              </svg>
              </div>
            </div>
            </div>`;
          button.onclick = () => {
        button.classList.add('animate-pop-in');
        setTimeout(() => button.classList.remove('animate-pop-in'), 300);
        toggleChapter(chapter, button);
          };
          container.appendChild(button);
        });
      }

      const selectAllBtn = document.getElementById('selectAllBtn');
      if (selectAllBtn) {
        selectAllBtn.className = 'flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white font-bold rounded-xl transition transform hover:scale-105 shadow-md flex items-center justify-center space-x-2 max-sm:hidden';
        selectAllBtn.innerHTML = `
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
          </svg>
          <span>Select All</span>
        `;
        selectAllBtn.addEventListener('click', toggleAllChapters);
      }

      const startQuizBtn = document.getElementById('startQuizBtn');
      if (startQuizBtn) {
        startQuizBtn.addEventListener('click', startQuizHandler);
      }

      const nextBtn = document.getElementById('nextBtn');
      if (nextBtn) {
        nextBtn.addEventListener('click', nextQuestion);
      }

      const prevBtn = document.getElementById('prevBtn');
      if (prevBtn) {
        prevBtn.addEventListener('click', prevQuestion);
      }

      // Toggle chapter selection
      function toggleChapter(chapter, button) {
        const index = selectedChapters.indexOf(chapter);
        if (index === -1) {
          selectedChapters.push(chapter);
          button.classList.add('border-purple-500', 'bg-purple-100');
          button.querySelector('.checkmark').classList.remove('opacity-0');
        } else {
          selectedChapters.splice(index, 1);
          button.classList.remove('border-purple-500', 'bg-purple-100');
          button.querySelector('.checkmark').classList.add('opacity-0');
        }
        updateSelectionUI();
      }

      // Toggle all chapters
      function toggleAllChapters() {
        const buttons = document.querySelectorAll('#chapterSelection .grid button');
        if (selectedChapters.length === chapters.length) {
          selectedChapters = [];
          buttons.forEach(button => {
            button.classList.remove('border-purple-500', 'bg-purple-100');
            button.querySelector('.checkmark').classList.add('opacity-0');
          });
        } else {
          selectedChapters = [...chapters];
          buttons.forEach(button => {
            button.classList.add('border-purple-500', 'bg-purple-100');
            button.querySelector('.checkmark').classList.remove('opacity-0');
          });
        }
        updateSelectionUI();
      }

      // Update selection UI
      function updateSelectionUI() {
        const selectedCount = document.getElementById('selectedCount');
        const selectedCountBtn = document.getElementById('selectedCountBtn');
        const startQuizBtn = document.getElementById('startQuizBtn');

        if (selectedCount) selectedCount.textContent = selectedChapters.length;
        if (selectedCountBtn) selectedCountBtn.textContent = selectedChapters.length;
        if (startQuizBtn) startQuizBtn.disabled = selectedChapters.length === 0;

        const selectAllBtn = document.getElementById('selectAllBtn');
        if (selectAllBtn) {
          selectAllBtn.textContent =
            selectedChapters.length === chapters.length ? 'Deselect All' : 'Select All';
        }
      }

      // Start quiz handler
      async function startQuizHandler() {
        if (selectedChapters.length === 0) return;
        const chapterSelection = document.getElementById('chapterSelection');
        const loading = document.getElementById('loading');

        if (chapterSelection) chapterSelection.classList.add('hidden');
        if (loading) loading.classList.remove('hidden');

        try {
          // Simulate API call to generate quiz data
          const userInput = `Generate a dynamic set of between 10 and 100 extremely challenging and rigorously-formatted multiple-choice questions (MCQs) in XML format. Follow the structure below:
    <mcqs>       <mcq>         <question>ঈশ্বরচন্দ্র বিদ্যাসাগরের জন্মস্থান কোন জেলায়?</question>         <options>           <option id="1">হুগলী</option>           <option id="2">মেদিনীপুর</option>           <option id="3">বর্ধমান</option>           <option id="4">নদীয়া</option>         </options>         <answer>2</answer>       </mcq>     </mcqs>
    Question difficulty hard.
    Ensure every generated quiz contains uniquely difficult and contextually-rich questions with carefully selected distractors and a detailed explanation for each correct answer. The content should rigorously reflect the academic concepts presented in the following chapters: ${selectedChapters.join(', ')}.The higher the user's score, the more difficult the questions will become. User score is <?= $score; ?>`;
          const encodedUserInput = encodeURIComponent(userInput);

          const response = await fetch(`/ai/index.php?user_input=${encodedUserInput}&class=<?= $class; ?>&subject=<?= $subject; ?>`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json'
            }
          });

          const data = await response.json();
          if (data.error) throw new Error(data.error);
          quizData = Array.isArray(data) ? data : data.raw_text;
          startQuiz();
        } catch (error) {
          alert(`Error: ${error.message}`);
          location.reload();
        }
      }

      // Start quiz
      function startQuiz() {
        const loading = document.getElementById('loading');
        const quizContainer = document.getElementById('quizContainer');

        if (loading) loading.classList.add('hidden');
        if (quizContainer) quizContainer.classList.remove('hidden');

        const maxScore = document.getElementById('maxScore');
        if (maxScore) maxScore.textContent = quizData.length;

        startTimer();
        showQuestion(currentQuestion);
      }

      // Timer functions
      function startTimer() {
        totalTime = quizData.length * timePerQuestion; // Total time = number of questions * time per question
        timeLeft = totalTime;
        updateTimerDisplay();

        timer = setInterval(() => {
          timeLeft--;
          updateTimerDisplay();
          if (timeLeft <= 0) {
            clearInterval(timer);
            showResults();
          }
        }, 1000);
      }

      function updateTimerDisplay() {
        const timerElement = document.getElementById('timer');
        if (timerElement) {
          const minutes = Math.floor(timeLeft / 60);
          const seconds = timeLeft % 60;
          timerElement.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }
      }

      // Show question
      function showQuestion(index) {
        const question = quizData[index];
        const questionText = document.getElementById('questionText');
        const optionsContainer = document.getElementById('options');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');

        if (questionText) questionText.textContent = question.mcq;
        if (optionsContainer) {
          optionsContainer.innerHTML = '';
          Object.entries(question.options).forEach(([key, value]) => {
            const button = document.createElement('button');
            button.className = 'text-left max-sm:text-sm p-4 rounded-lg bg-white hover:bg-purple-50 border-2 border-gray-200 transition-all shadow-sm hover:shadow-md';
            button.innerHTML = `<span class="font-semibold">${key}.</span> ${value}`;
            button.onclick = () => selectAnswer(key, question.answer, button);
            optionsContainer.appendChild(button);
          });
        }

        if (prevBtn) prevBtn.classList.toggle('hidden', index === 0);
        if (nextBtn) nextBtn.textContent = index === quizData.length - 1 ? 'Finish' : 'Next';

        updateProgress();
      }

      // Select answer
      function selectAnswer(selected, correct, button) {
        const allButtons = document.querySelectorAll('#options button');
        allButtons.forEach(btn => {
          btn.classList.remove('border-green-500', 'bg-green-100', 'border-red-500', 'bg-red-100');
          btn.disabled = true;
        });

        const isCorrect = selected === correct;
        if (isCorrect) {
          button.classList.add('border-green-500', 'bg-green-100');
          playCorrectSound();
          updateStreak(true);
          score++;
          const scoreElement = document.getElementById('score');
          if (scoreElement) scoreElement.textContent = score;
        } else {
          button.classList.add('border-red-500', 'bg-red-100');
          playWrongSound();
          updateStreak(false);
          // Highlight correct answer
          allButtons.forEach(btn => {
            if (btn.textContent.startsWith(correct + '.')) {
              btn.classList.add('border-green-500', 'bg-green-100');
            }
          });
        }
      }

      // Update progress
      function updateProgress() {
        const progressBar = document.getElementById('progressBar');
        if (progressBar) {
          const progress = ((currentQuestion + 1) / quizData.length) * 100;
          progressBar.style.width = `${progress}%`;
        }
      }

      // Next question
      function nextQuestion() {
        if (currentQuestion < quizData.length - 1) {
          currentQuestion++;
          showQuestion(currentQuestion);
        } else {
          showResults();
        }
      }

      // Previous question
      function prevQuestion() {
        if (currentQuestion > 0) {
          currentQuestion--;
          showQuestion(currentQuestion);
        }
      }

      function showResults() {
    playCompleteSound();
    clearInterval(timer);
    triggerConfetti();
    const quizContainer = document.getElementById('quizContainer');
    const results = document.getElementById('results');
    const finalScore = document.getElementById('finalScore');
    const correctAnswers = document.getElementById('correctAnswers');
    const wrongAnswers = document.getElementById('wrongAnswers');
    const timeTaken = document.getElementById('timeTaken');

    if (quizContainer) quizContainer.classList.add('hidden');
    if (results) results.classList.remove('hidden');
    if (finalScore) finalScore.textContent = score;
    if (correctAnswers) correctAnswers.textContent = score;
    if (wrongAnswers) wrongAnswers.textContent = quizData.length - score;
    if (timeTaken) timeTaken.textContent = `${totalTime - timeLeft}s`;

    // Send the score to userscore.php using AJAX
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/userscore.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log("Score sent successfully!");
        }
    };
    xhr.send(`score=${score}`);
}
      // Streak counter
      function updateStreak(isCorrect) {
        if (isCorrect) {
          streakCounter++;
        } else {
          streakCounter = 0;
        }
        const streakElement = document.getElementById('streak');
        if (streakElement) streakElement.textContent = streakCounter;
      }

      // Confetti effect
      function triggerConfetti() {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      }

      // Sound effects
      function playCorrectSound() {
        const correctSound = document.getElementById('correctSound');
        if (correctSound) correctSound.play();
      }

      function playWrongSound() {
        const wrongSound = document.getElementById('wrongSound');
        if (wrongSound) wrongSound.play();
      }
      function playCompleteSound() {
          const wrongSound = document.getElementById('completeSound');
          if (wrongSound  ) wrongSound.play();
        }
    });
   
  </script>
  <script>
      var questionText = document.getElementById("questionText");
      if (questionText) {
        // Regex to match fractions like "a/b", "1/2", "x/y", etc.
        const fractionRegex = /(\d+|\w+)\/(\d+|\w+)/g;

        // Replace all fractions with formatted spans
        questionText.innerHTML = questionText.innerHTML.replace(
          fractionRegex,
          (match, numerator, denominator) => {
            return `<span class="derivative">
                      <span class="numerator">${numerator}</span>
                      <span class="denominator">${denominator}</span>
                    </span>`;
          }
        );
      }

        </script>
</body>
</html>


