
<?php
require 'db/db.php';
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_phone'] = $user['phone'];
        $_SESSION['full_name'] = $user['full_name'];
    } else {
        session_destroy();
        setcookie('remember_me', '', time() - 3600, '/');
    }
    $stmt = $pdo->prepare("SELECT SUM(score) as total_score FROM user_scores WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id'] ?? 0]);
$scoreData = $stmt->fetch();
$totalScore = $scoreData['total_score'] ?? 0;

$stmt = $pdo->prepare("
    SELECT rank 
    FROM (
        SELECT user_id, DENSE_RANK() OVER (ORDER BY total_score DESC) as rank
        FROM (
            SELECT user_id, SUM(score) as total_score 
            FROM user_scores 
            GROUP BY user_id
        ) scores
    ) rankings 
    WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id'] ?? 0]);
$rankData = $stmt->fetch();
$userRank = $rankData['rank'] ?? 'N/A';
}
?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;700&display=swap');
    body {
        font-family: 'Noto Sans Bengali', sans-serif;
    }
    .navbar {
        backdrop-filter: blur(15px);
        background: rgba(255, 255, 255, 0.9);
        border-bottom: 1px solid rgba(229, 231, 235, 0.5);
    }
    .nav-link {
        position: relative;
        transition: all 0.3s ease;
    }
    .nav-link::after {
        content: '';
        position: absolute;
        width: 0;
        height: 2px;
        bottom: -4px;
        left: 0;
        background-color: #3B82F6;
        transition: width 0.3s ease;
    }
    .nav-link:hover::after {
        width: 100%;
    }
    .login-btn {
        background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .login-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
    }
    #mobile-menu {
        transition: all 0.3s ease;
        transform-origin: top;
    }
    #mobile-menu.hidden {
        display: none;
        transform: scaleY(0);
    }
</style>
<div class="sm:hidden relative overflow-hidden bg-gradient-to-r from-blue-600 via-blue-500 to-blue-700 text-white py-3 app-hide">
    <div class="absolute top-0 left-0 w-full h-full">
        <div class="absolute inset-0 opacity-10">
            <div class="absolute transform rotate-45 translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white rounded-full"></div>
            <div class="absolute right-0 transform rotate-45 translate-x-1/2 translate-y-1/2 w-48 h-48 bg-white rounded-full"></div>
        </div>
    </div>
    <div class="container mx-auto px-4 relative">
        <div class="flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <div class="bg-white/20 p-2 rounded-lg">
                    <i class="fas fa-mobile-alt text-xl animate-pulse"></i>
                </div>
                <div>
                    <p class="font-bold text-sm">অ্যাপ এখন উপলব্ধ!</p>
                </div>
            </div>
            <div class="flex items-center space-x-2">
                <a href="/quizmafia.apk" download class="bg-white hover:bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-sm font-bold transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2">
                    <i class="fab fa-android text-green-500"></i>
                    <span>ডাউনলোড</span>
                </a>
                <button onclick="this.parentElement.parentElement.parentElement.parentElement.remove()" 
                        class="p-1.5 hover:bg-white/10 rounded-full transition-colors">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<nav class="navbar sticky fixed top-0 w-full z-50 shadow-md">
    <div class="container mx-auto px-2 py-2 sm:px-4 sm:py-4">
        <div class="flex justify-between items-center">
            <div class="flex items-center space-x-4">
                <a href="/#" class="transform hover:scale-105 transition-transform">
                    <img src="/img/logo.svg" alt="logo" class="w-32 sm:w-36 max-sm:p-2.5">
                </a>
            </div>
            <div class="hidden md:flex items-center space-x-6">
                <a href="/#home" class="nav-link text-gray-700 hover:text-blue-500">হোম</a>
                <a href="/start" class="nav-link text-gray-700 hover:text-blue-500">কুইজ</a>
                <a href="/features" class="nav-link text-gray-700 hover:text-blue-500"><span class="font-semibold text-blue-600">AI</span> টুলস</a>
                <a href="/leaderboard" class="nav-link text-gray-700 hover:text-blue-500">লিডারবোর্ড</a>
                <a href="/#contact" class="nav-link text-gray-700 hover:text-blue-500">যোগাযোগ</a>
            </div>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <div class="hidden md:flex items-center space-x-6">
                    <a href="/dashboard" class="nav-link">
                    <img class="size-9 rounded-full object-cover " 
                                 src="<?= !empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic']) ? '/uploads/' . htmlspecialchars($user['profile_pic']) : 'https://avatar.iran.liara.run/username?username=' . urlencode($user['full_name']) ?>" 
                                 alt="Profile Picture">
                    </a>
                </div>
            <?php } else { ?>
                <div class="hidden md:block">
                    <a href="/login" class="login-btn text-white px-6 py-2.5 rounded-full font-bold">
                        লগইন
                    </a>
                </div>
            <?php } ?>
            <div class="md:hidden flex items-center space-x-3">
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="/dashboard" class="flex items-center">
                        <img class="size-8 rounded-full object-cover border-2 border-blue-500" 
                             src="<?= !empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic']) ? '/uploads/' . htmlspecialchars($user['profile_pic']) : 'https://avatar.iran.liara.run/username?username=' . urlencode($user['full_name']) ?>" 
                             alt="Profile">
                    </a>
                <?php } else { ?>
                    <a href="/register" class="login-btn text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-blue-600 transition-colors">
                    রেজিষ্টার
                    </a>
                <?php } ?>
                <button id="menu-button" class="focus:outline-none p-2 rounded-full hover:bg-gray-100 transition-colors">
                    <i class="fas fa-bars text-lg text-gray-600"></i>
                </button>
            </div>
        </div>
    </div>
    <!-- Mobile Menu -->
    <div id="mobile-menu" class="md:hidden hidden bg-white py-6 px-6 shadow-xl border-t">
        <a href="/#home" class="block py-3 text-gray-700 hover:text-blue-500 hover:bg-blue-50 rounded-lg px-4 transition">হোম</a>
        <a href="/start" class="block py-3 text-gray-700 hover:text-blue-500 hover:bg-blue-50 rounded-lg px-4 transition">কুইজ</a>
        <a href="/features" class="block py-3 text-gray-700 hover:text-blue-500 hover:bg-blue-50 rounded-lg px-4 transition"><span class="font-semibold text-blue-600">AI</span> টুলস</a>
        <a href="/leaderboard" class="block py-3 text-gray-700 hover:text-blue-500 hover:bg-blue-50 rounded-lg px-4 transition">লিডারবোর্ড</a>
        <a href="/#contact" class="block py-3 text-gray-700 hover:text-blue-500 hover:bg-blue-50 rounded-lg px-4 transition">যোগাযোগ</a>
        <?php if (isset($_SESSION['user_id'])) { ?>
        <?php } else { ?>
            <a href="/login" class="mt-4 login-btn text-white px-6 py-3 rounded-lg font-bold block text-center">
                লগইন
            </a>
        <?php } ?>
    </div>
</nav>
<script>
    document.getElementById('menu-button').addEventListener('click', function() {
        const mobileMenu = document.getElementById('mobile-menu');
        mobileMenu.classList.toggle('hidden');
    });
</script>
 <!-- Bottom Icon Bar -->
 <div class="fixed sm:hidden bottom-6 left-1/2 transform -translate-x-1/2 bg-white/90 backdrop-blur-lg rounded-full shadow-xl border border-blue-100 px-3 py-2 z-50 w-[90%] sm:w-auto">
        <div class="flex items-center justify-evenly sm:justify-center">
            <a href="/" class="flex flex-col items-center group w-16 sm:w-20 mx-1 sm:mx-4">
                <i class="fas fa-home text-lg sm:text-xl text-blue-500 group-hover:scale-110 transition-transform"></i>
                <span class="text-[10px] sm:text-xs text-gray-600 mt-1">হোম</span>
            </a>
            <a href="/start" class="flex flex-col items-center group w-16 sm:w-20 mx-1 sm:mx-4">
                <i class="fas fa-book text-lg sm:text-xl text-green-500 group-hover:scale-110 transition-transform"></i>
                <span class="text-[10px] sm:text-xs text-gray-600 mt-1">ক্লাস</span>
            </a>
            <a href="/leaderboard" class="flex flex-col items-center group w-16 sm:w-20 mx-1 sm:mx-4">
                <i class="fas fa-trophy text-lg sm:text-xl text-yellow-500 group-hover:scale-110 transition-transform"></i>
                <span class="text-[10px] sm:text-xs text-gray-600 mt-1">লিডারবোর্ড</span>
            </a>
            <a href="/dashboard" class="flex flex-col items-center group w-16 sm:w-20 mx-1 sm:mx-4">
                <i class="fas fa-user text-lg sm:text-xl text-purple-500 group-hover:scale-110 transition-transform"></i>
                <span class="text-[10px] sm:text-xs text-gray-600 mt-1">প্রোফাইল</span>
            </a>
        </div>
    </div>
<style>
    body{
        padding-bottom: 70px;
    }
</style>