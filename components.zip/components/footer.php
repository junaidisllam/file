<footer id="contact" class="bg-blue-50 text-gray-800 pt-20 pb-6 relative overflow-hidden">
    <!-- Decorative Elements -->
    <div class="absolute inset-0 overflow-hidden">
        <!-- Floating Circles -->
        <div class="circle-1 w-32 h-32 bg-blue-200 rounded-full absolute top-20 left-10 animate-float opacity-50"></div>
        <div class="circle-2 w-24 h-24 bg-purple-200 rounded-full absolute top-40 right-20 animate-float-delayed opacity-40"></div>
        <div class="circle-3 w-16 h-16 bg-pink-200 rounded-full absolute bottom-20 left-1/4 animate-float opacity-30"></div>
        
        <!-- Light Beams -->
        <div class="light-beam-1 absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-400/20 to-transparent rotate-45 blur-3xl"></div>
        <div class="light-beam-2 absolute -bottom-20 -right-20 w-96 h-96 bg-gradient-to-l from-purple-400/20 to-transparent rotate-45 blur-3xl"></div>
    </div>

    <div class="container mx-auto px-4 relative z-10">
        <!-- Footer Top Section -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
        <!-- Brand Section -->
        <div class="space-y-6">
            <h3 class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">কুইজ মাফিয়া</h3>
            <p class="text-gray-600 leading-relaxed">ষষ্ঠ থেকে দশম শ্রেণীর ছাত্রছাত্রীদের জন্য বাংলাদেশের সেরা AI-ভিত্তিক কুইজ প্ল্যাটফর্ম।</p>
            <!-- Download APK Button -->
            <a href="/quizmafia.apk" download class="inline-flex items-center px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 download-btn">
            <i class="fab fa-android text-2xl mr-3 app-hide"></i>
            <div class="flex flex-col">
                <span class="text-xs">Download Now</span>
                <span class="text-sm">Get the Quiz Mafia App</span>
            </div>
            </a>
            <div class="pt-4">
            <div class="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
            </div>
        </div>

        <!-- Quick Links -->
        <div class="space-y-6">
            <h4 class="text-xl font-bold text-gray-800">দ্রুত লিঙ্ক</h4>
            <ul class="space-y-4">
            <li><a href="#home" class="text-gray-600 hover:text-blue-600 hover:translate-x-2 transition-all duration-300 flex items-center"><i class="fas fa-chevron-right mr-2 text-blue-500"></i>হোম</a></li>
            <li><a href="#features" class="text-gray-600 hover:text-blue-600 hover:translate-x-2 transition-all duration-300 flex items-center"><i class="fas fa-chevron-right mr-2 text-blue-500"></i>বৈশিষ্ট্য</a></li>
            <li><a href="#classes" class="text-gray-600 hover:text-blue-600 hover:translate-x-2 transition-all duration-300 flex items-center"><i class="fas fa-chevron-right mr-2 text-blue-500"></i>শ্রেণী</a></li>
            <li><a href="#testimonials" class="text-gray-600 hover:text-blue-600 hover:translate-x-2 transition-all duration-300 flex items-center"><i class="fas fa-chevron-right mr-2 text-blue-500"></i>অভিমত</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="space-y-6">
            <h4 class="text-xl font-bold text-gray-800">যোগাযোগ</h4>
            <ul class="space-y-4">
            <li class="flex items-center text-gray-600 hover:text-blue-600 transition-colors duration-300">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                <i class="fas fa-envelope text-blue-500"></i>
                </div>
                info@quizmafia.com
            </li>
            <li class="flex items-center text-gray-600 hover:text-blue-600 transition-colors duration-300">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                <i class="fas fa-phone text-blue-500"></i>
                </div>
                +880 1712-345678
            </li>
            <li class="flex items-center text-gray-600 hover:text-blue-600 transition-colors duration-300">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                <i class="fas fa-map-marker-alt text-blue-500"></i>
                </div>
                মিরপুর-১০, ঢাকা
            </li>
            </ul>
        </div>
        </div>

        <!-- Footer Bottom -->
        <div class="pt-8 border-t border-blue-200">
        <div class="text-center text-gray-600 text-sm">
            <p class="hover:text-blue-600 transition-colors duration-300">&copy; ২০২৫ কুইজ মাফিয়া। সর্বস্বত্ব সংরক্ষিত।</p>
            <p class="mt-2 text-sm text-gray-500">Developed by Junaid Ahmed</p>
        </div>
        </div>
    </div>
    </footer>
