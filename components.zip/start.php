<?php session_start(); ?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>কুইজ মাফিয়া - AI কুইজ অ্যাপ্লিকেশন</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <?php include "./components/navbar.php"; ?>
    <!-- Hero Section -->
    <!-- Class Categories -->
    <section id="classes" class="pt-10 bg-gradient-to-b from-blue-50 via-white to-blue-50">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-20">
                <span class="text-blue-600 font-semibold text-sm tracking-wider uppercase mb-2 inline-block">আপনার শ্রেণী বাছাই করুন</span>
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">শ্রেণী অনুযায়ী <span class="text-blue-600">কুইজ</span></h2>
                <p class="text-gray-600 text-lg leading-relaxed">আপনার শ্রেণী অনুযায়ী উপযুক্ত কুইজ বেছে নিয়ে আজই শুরু করুন আপনার জ্ঞান যাত্রা</p>
                <div class="h-1.5 w-24 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
                <!-- Class 6 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-blue-400 to-blue-600 flex items-center justify-center">
                        <span class="text-white text-8xl font-bold group-hover:scale-125 transform transition-transform duration-500">৬</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">ষষ্ঠ শ্রেণী</h3>
                        <a href="/class/6/books" class="block w-full bg-white text-blue-600 border-2 border-blue-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>

                <!-- Class 7 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-green-400 to-green-600 flex items-center justify-center">
                        <span class="text-white text-8xl font-bold group-hover:scale-125 transform transition-transform duration-500">৭</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">সপ্তম শ্রেণী</h3>
                        <a href="/class/7/books" class="block w-full bg-white text-green-600 border-2 border-green-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>

                <!-- Class 8 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-purple-400 to-purple-600 flex items-center justify-center">
                        <span class="text-white text-8xl font-bold group-hover:scale-125 transform transition-transform duration-500">৮</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">অষ্টম শ্রেণী</h3>
                        <a href="/class/8/books" class="block w-full bg-white text-purple-600 border-2 border-purple-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>

                <!-- Class 9-10 -->
                <div class="group relative bg-white rounded-3xl shadow-xl overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                    <div class="h-48 bg-gradient-to-r from-pink-400 to-pink-600 flex items-center justify-center">
                        <span class="text-white text-7xl font-bold group-hover:scale-125 transform transition-transform duration-500">৯-১০</span>
                    </div>
                    <div class="p-8">
                        <h3 class="font-bold text-2xl text-center mb-6 text-gray-800">নবম-দশম শ্রেণী</h3>
                        <a href="/class/9/books" class="block w-full bg-white text-pink-600 border-2 border-pink-600 py-4 px-6 rounded-2xl transition-all duration-500 text-center font-bold text-lg transform hover:scale-105 shadow-lg hover:shadow-xl">
                            <i class="fas fa-graduation-cap mr-2"></i>শুরু করুন
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include"./components/footer.php"; ?>

    <script>
     

        // Smooth Scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Start animation
        window.onload = function() {
            typeWriter();
        }
    </script>
</body>
</html>