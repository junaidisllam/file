<?php session_start(); ?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>কুইজ মাফিয়া - 404 </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        
        .typewriter-container {
            position: relative;
            display: inline-block;
        }
        .typewriter {
            border-right: 3px solid #3B82F6;
            overflow: hidden;
            display: inline-block;
        }
        @keyframes typing {
            from { width: 0 }
            to { width: 100% }
        }
        @keyframes blink-cursor {
            from, to { border-color: transparent }
            50% { border-color: #3B82F6 }
        }
        .wave {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
            line-height: 0;
        }
        .wave svg {
            position: relative;
            display: block;
            width: calc(100% + 1.3px);
            height: 150px;
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <?php include "./components/navbar.php"; ?>
    
<!-- 404 Page -->
<section id="page-404" class="py-24 bg-gradient-to-b from-blue-50 to-white min-h-screen flex items-center">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto text-center">
            <div class="mb-8 relative">
                <h1 class="text-9xl font-bold text-blue-600 mb-4">404</h1>
                <p class="text-2xl text-gray-600 mb-8">দুঃখিত, আপনার অনুরোধকৃত পেজটি খুঁজে পাওয়া যায়নি</p>
                <div class="w-24 h-1 bg-blue-600 mx-auto rounded-full"></div>
            </div>
            
            <div class="flex flex-col sm:flex-row justify-center gap-4">
                <a href="/" class="inline-block bg-blue-600 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition transform hover:-translate-y-1 hover:shadow-xl hover:bg-blue-700">
                    <i class="fas fa-home mr-2"></i>
                    হোম পেজে ফিরুন
                </a>
                <a href="/contact" class="inline-block bg-white text-blue-600 font-bold py-3 px-8 rounded-lg shadow-lg border-2 border-blue-600 transition transform hover:-translate-y-1 hover:shadow-xl">
                    <i class="fas fa-envelope mr-2"></i>
                    যোগাযোগ করুন
                </a>
            </div>

            <div class="mt-12">
                <svg viewBox="0 0 800 400" class="max-w-md mx-auto">
                    <!-- Background circles -->
                    <circle cx="400" cy="200" r="150" fill="#EBF5FF" />
                    <circle cx="400" cy="200" r="100" fill="#BFDBFE" />
                    
                    <!-- Sad face -->
                    <circle cx="350" cy="180" r="10" fill="#2563EB" />
                    <circle cx="450" cy="180" r="10" fill="#2563EB" />
                    <path d="M 320 250 Q 400 200 480 250" stroke="#2563EB" stroke-width="8" fill="none" />
                    
                    <!-- Decorative elements -->
                    <circle cx="200" cy="100" r="20" fill="#93C5FD" opacity="0.5" />
                    <circle cx="600" cy="300" r="30" fill="#93C5FD" opacity="0.5" />
                    <circle cx="150" cy="300" r="15" fill="#93C5FD" opacity="0.5" />
                    <circle cx="650" cy="150" r="25" fill="#93C5FD" opacity="0.5" />
                    
                    <!-- Question marks -->
                    <text x="250" y="150" font-size="40" fill="#2563EB" opacity="0.5">?</text>
                    <text x="500" y="100" font-size="60" fill="#2563EB" opacity="0.5">?</text>
                    <text x="450" y="300" font-size="50" fill="#2563EB" opacity="0.5">?</text>
                </svg>
            </div>
        </div>
    </div>
</section>
    <?php include"./components/footer.php"; ?>
</body>
</html>