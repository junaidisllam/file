<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Folder Uploader</title>
</head>
<body>
    <h2>Upload a Folder</h2>
    <form id="uploadForm" action="http://quizmafia.rf.gd/fileupload.php" method="post" enctype="multipart/form-data">
        <input type="file" id="folderInput" name="files[]" webkitdirectory directory multiple required>
        <button type="submit">Upload</button>
    </form>
</body>
</html>


