<?php
// Start session to access user data
session_start();

// Include database connection
include('db/db.php');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the score from the POST data
    $score = isset($_POST['score']) ? intval($_POST['score']) : 0;

    // Check if the user is logged in (user_id exists in session)
    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];

        // Check if the user already has a score in the database
        $checkStmt = $connection->prepare("SELECT score FROM user_scores WHERE user_id = ?");
        $checkStmt->bind_param("i", $userId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            // User exists: Update their score by adding the new score
            $updateStmt = $connection->prepare("UPDATE user_scores SET score = score + ? WHERE user_id = ?");
            $updateStmt->bind_param("ii", $score, $userId);
            if ($updateStmt->execute()) {
                echo "Score updated successfully!";
            } else {
                echo "Error updating score: " . $connection->error;
            }
            $updateStmt->close();
        } else {
            // User does not exist: Insert a new score
            $insertStmt = $connection->prepare("INSERT INTO user_scores (user_id, score) VALUES (?, ?)");
            $insertStmt->bind_param("ii", $userId, $score);
            if ($insertStmt->execute()) {
                echo "Score saved successfully!";
            } else {
                echo "Error saving score: " . $connection->error;
            }
            $insertStmt->close();
        }
        $checkStmt->close();
    } else {
        // User is not logged in
        echo "User not logged in!";
    }
} else {
    // Invalid request method
    echo "Invalid request method.";
}

// Close the database connection
$connection->close();
?>