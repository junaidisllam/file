<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>গণিত চ্যাট সহকারী</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/default.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* MathJax Fixes */
        mjx-container[jax="SVG"] {
            font-family: 'Noto Sans Bengali', sans-serif !important;
        }
        mjx-mtext, mjx-mi, mjx-mo, mjx-mn {
            font-family: 'Noto Sans Bengali', sans-serif !important;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fadeIn 0.3s ease-in-out;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-blue-100 min-h-screen flex justify-center items-center p-4 sm:p-6">
    <!-- Main Chat Container -->
    <div class="w-full max-w-4xl h-[90vh] sm:h-[80vh] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        <!-- Header -->
        <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-4 sm:p-6">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-full flex items-center justify-center">
                    <i class="fas fa-robot text-xl sm:text-2xl text-blue-600"></i>
                </div>
                <div>
                    <h1 class="text-xl sm:text-2xl font-bold text-white">গণিত চ্যাট সহকারী</h1>
                    <p class="text-sm text-blue-100">আপনার গণিত সমস্যার সমাধানে সহায়তা করবো</p>
                </div>
            </div>
        </div>

        <!-- Chat Messages Container -->
        <div id="chatContainer" class="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            <!-- Welcome Message -->
            <div class="bot-message animate-fade-in">
                <div class="flex items-center gap-2 mb-2">
                    <i class="fas fa-robot text-blue-500"></i>
                    <span class="font-semibold">গণিত সহকারী</span>
                </div>
                <p class="text-sm sm:text-base">স্বাগতম! আমি আপনার গণিত সমস্যা সমাধানে সাহায্য করতে প্রস্তুত। আপনি টেক্সট লিখতে পারেন অথবা ছবি আপলোড করতে পারেন।</p>
            </div>
        </div>

        <!-- Input Area -->
        <div class="p-4 sm:p-6 bg-white border-t border-blue-100">
            <div class="flex flex-col gap-3">
                <!-- Image Preview -->
                <div id="imagePreview" class="hidden relative group">
                    <img class="max-w-full h-32 object-contain rounded-lg border border-blue-200"/>
                    <button onclick="clearImage()" class="absolute top-0 right-0 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center shadow-lg hover:bg-red-600 transition-all">
                        <i class="fas fa-times text-xs"></i>
                    </button>
                </div>

                <!-- Input Group -->
                <div class="flex gap-2">
                    <input type="file" id="imageUpload" class="hidden" onchange="handleImageUpload(this)">
                    <label for="imageUpload" class="bg-blue-500 text-white p-2 sm:p-3 rounded-lg cursor-pointer hover:bg-blue-600 transition-all">
                        <i class="fas fa-camera"></i>
                    </label>
                    
                    <input type="text" id="mathProblem" placeholder="আপনার প্রশ্ন লিখুন..." class="flex-1 p-2 sm:p-3 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm sm:text-base">
                    
                    <button onclick="sendMessage()" class="bg-blue-500 text-white p-2 sm:p-3 rounded-lg hover:bg-blue-600 transition-all flex items-center gap-2">
                        <span id="solveButtonText">পাঠান</span>
                        <i class="fas fa-paper-plane"></i>
                        <span id="loadingSpinner" class="hidden">
                            <i class="fas fa-circle-notch fa-spin"></i>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // MathJax Configuration
        MathJax = {
            tex: {
                inlineMath: [['$', '$']],
                displayMath: [['$$', '$$']],
                processEscapes: true
            },
            svg: { fontCache: 'global' },
            options: { 
                renderActions: { 
                    addMenu: [0, '', ''],
                    typeset: [150, (doc) => { MathJax.typesetPromise([doc]); }, '']
                } 
            }
        };

        const API_KEY = "AIzaSyDnp_ufdT4X2nrC2_pw6LkSXAK2UBez7M4";
        const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;
        
        let chatHistory = [];
        let uploadedImage = null;

        // Handle Image Upload
        async function handleImageUpload(input) {
            const file = input.files[0];
            const preview = document.getElementById('imagePreview');
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    uploadedImage = {
                        mimeType: file.type,
                        data: e.target.result.split(',')[1],
                        url: e.target.result
                    };
                    preview.classList.remove('hidden');
                    preview.querySelector('img').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        }

        // Clear Image
        function clearImage() {
            uploadedImage = null;
            document.getElementById('imageUpload').value = '';
            document.getElementById('imagePreview').classList.add('hidden');
        }

        // Add Message to Chat
        function addMessageToChat(message, isUser = false) {
            const chatContainer = document.getElementById('chatContainer');
            const messageDiv = document.createElement('div');
            messageDiv.className = `p-4 rounded-lg ${isUser ? 'bg-blue-100 ml-8' : 'bg-gray-100 mr-8'} animate-fade-in`;
            
            if (isUser && uploadedImage?.url) {
                messageDiv.innerHTML = `
                    <div class="mb-2">
                        <img src="${uploadedImage.url}" class="max-w-full h-32 object-contain rounded-lg"/>
                    </div>
                    <div class="text-gray-800">${message || 'আপলোডেড ছবি'}</div>
                `;
            } else {
                messageDiv.innerHTML = marked.parse(message);
            }
            
            chatContainer.appendChild(messageDiv);
            MathJax.typesetPromise([messageDiv]);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

        // Send Message
        async function sendMessage() {
            const problem = document.getElementById('mathProblem').value.trim();
            const solveButtonText = document.getElementById('solveButtonText');
            const loadingSpinner = document.getElementById('loadingSpinner');
            
            if (!problem && !uploadedImage) return;

            try {
                // UI Updates
                solveButtonText.textContent = 'প্রসেসিং...';
                loadingSpinner.classList.remove('hidden');
                document.getElementById('mathProblem').value = '';

                // Add User Message
                addMessageToChat(problem || 'ছবি বিশ্লেষণ করা হচ্ছে...', true);

                // Prepare API Request
                const parts = [];
                if (uploadedImage) parts.push({
                    inlineData: {
                        mimeType: uploadedImage.mimeType,
                        data: uploadedImage.data
                    }
                });
                if (problem) parts.push({ text: problem });

                const response = await fetch(API_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{
                            role: "user",
                            parts: parts
                        }],
                        systemInstruction: {
                            role: "user",
                            parts: [{
                                text: `বাংলায় গণিত সমাধান করুন। কঠোরভাবে মেনে চলুন:
                                1. শুধুমাত্র ইংরেজিতে সমীকরণ লিখুন ($$...$$ বা $...$)
                                2. বাংলা শুধুমাত্র সমীকরণের বাইরে
                                3. ধাপে ধাপে ব্যাখ্যা
                                4. Markdown ব্যবহার করবেন না`
                            }]
                        },
                        generationConfig: {
                            temperature: 0.7,
                            maxOutputTokens: 2000
                        }
                    })
                });

                const data = await response.json();
                const answer = data.candidates[0].content.parts[0].text;
                addMessageToChat(answer);
                
                // Clear Inputs
                document.getElementById('mathProblem').value = '';
                clearImage();

            } catch (error) {
                console.error('Error:', error);
                addMessageToChat('ত্রুটি: অনুগ্রহ করে আবার চেষ্টা করুন');
            } finally {
                solveButtonText.textContent = 'পাঠান';
                loadingSpinner.classList.add('hidden');
            }
        }

        // Handle Enter Key
        document.getElementById('mathProblem').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
    </script>
</body>
</html>