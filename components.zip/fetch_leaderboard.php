<?php
require 'db/db.php';

// Fetch top 10 users with their total scores and profile pictures
$stmt = $pdo->prepare("
    SELECT u.full_name, u.profile_pic, SUM(us.score) as total_score 
    FROM user_scores us
    JOIN users u ON us.user_id = u.id
    GROUP BY us.user_id
    ORDER BY total_score DESC
    LIMIT 100
");
$stmt->execute();
$leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Add profile picture URL to each user
foreach ($leaderboard as &$user) {
    $user['profile_pic'] = !empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic']) 
        ? 'uploads/' . htmlspecialchars($user['profile_pic']) 
        : 'https://avatar.iran.liara.run/username?username=' . urlencode($user['full_name']);
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($leaderboard);
?>