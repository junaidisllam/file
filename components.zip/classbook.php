<?php
$class = $_GET['class'];

?>
<?php
include __DIR__ . '/booksdata.php';
?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $class ?> শ্রেণীর বিষয় নির্বাচন করুন</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;700&display=swap');
        body { 
            font-family: 'Noto Sans Bengali', sans-serif;
            background: linear-gradient(135deg, #f0f7ff 0%, #f5f3ff 100%);
        }
        .custom-shape {
            clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
            opacity: 0;
            animation: fadeIn 0.5s ease-out forwards;
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
        .float-animation {
            animation: float 6s ease-in-out infinite;
        }
        .glass-effect {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
    </style>
</head>
<body>
    <?php include "./components/navbar.php"; ?>
    
    <!-- Enhanced Background Elements -->
    <div class="fixed inset-0 -z-10 overflow-hidden">
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div class="absolute bottom-0 left-1/2 w-96 h-96 bg-pink-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
    </div>

    <main class="container mx-auto px-4 py-8">
        <!-- Enhanced Header Section -->
        <div class="custom-shape bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 p-12 mb-12 rounded-3xl shadow-2xl relative overflow-hidden fade-in">
            <div class="absolute inset-0 bg-white/5 background-pattern"></div>
            <h1 class="text-4xl md:text-5xl font-bold text-white mb-6 text-center tracking-tight">
                <?= $class ?> শ্রেণীর বিষয় নির্বাচন করুন
            </h1>
            <p class="text-blue-100 text-center text-xl max-w-2xl mx-auto leading-relaxed">
                আপনার পছন্দের বিষয়টি নির্বাচন করে শিখন যাত্রা শুরু করুন
            </p>
            <div class="absolute -right-12 -bottom-12 text-9xl text-white/10">
                <i class="fas fa-graduation-cap"></i>
            </div>
        </div>

        <!-- Enhanced Search Bar -->
        <div class="max-w-xl mx-auto mb-12 fade-in" style="animation-delay: 0.2s;">
            <div class="relative group">
                <input type="text" id="searchSubjects" 
                       class="w-full px-8 py-4 rounded-full border-2 border-blue-200 focus:border-blue-400 
                              focus:ring-4 focus:ring-blue-100 outline-none transition-all duration-300
                              shadow-xl glass-effect text-lg" 
                       placeholder="বিষয় খুঁজুন...">
                <i class="fas fa-search absolute right-6 top-1/2 transform -translate-y-1/2 text-gray-400 
                          group-hover:text-blue-500 transition-colors duration-300 text-xl"></i>
            </div>
        </div>

        <!-- Enhanced Subjects Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            <?php
            foreach ($subjects as $index => $subject) {
                echo '
                <a href="/quiz/'.$class.'/'.urlencode($subject).'" 
                   class="glass-effect p-8 rounded-[2rem] shadow-2xl hover:shadow-3xl transition-all 
                          duration-500 hover:-translate-y-3 
                          flex flex-col items-center justify-center text-center group
                          relative overflow-hidden fade-in"
                   style="animation-delay: '.($index * 0.1).'s;">
                    <div class="relative z-10">
                        <div class="w-28 h-28 bg-gradient-to-br from-blue-400 to-indigo-500 
                                  rounded-2xl mb-6 mx-auto flex items-center justify-center 
                                  group-hover:scale-110 transition-all duration-500
                                  shadow-lg group-hover:rotate-6 relative overflow-hidden
                                  ring-8 ring-blue-100/30 group-hover:ring-blue-200 float-animation">
                            <i class="fas fa-book-open text-5xl text-white/90
                                   group-hover:text-white transform transition-all duration-500
                                   group-hover:rotate-12 group-hover:scale-110"></i>
                        </div>
                        <h3 class="font-bold text-2xl text-gray-800 group-hover:text-blue-600 
                                 transition-colors duration-300 mb-4">'.$subject.'</h3>
                    </div>
                </a>';
            }
            ?>
        </div>

        <?php if(empty($subjects)): ?>
            <div class="text-center py-16 glass-effect rounded-3xl shadow-2xl max-w-2xl mx-auto mt-12 fade-in" style="animation-delay: 0.3s;">
                <div class="text-7xl text-gray-300 mb-6 float-animation">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <p class="text-gray-600 text-2xl mb-6">এই শ্রেণীর জন্য কোনো বিষয় পাওয়া যায়নি</p>
                <a href="/" class="inline-flex items-center gap-3 text-blue-600 hover:text-blue-700 text-lg hover:translate-x-2 transition-all duration-300">
                    <i class="fas fa-arrow-left"></i> হোম পেজে ফিরে যান
                </a>
            </div>
        <?php endif; ?>
    </main>
    <?php include "./components/footer.php"; ?>

    <script>
    function debounce(func, delay) {
        let timeoutId;
        return function(...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    }

    const searchInput = document.getElementById('searchSubjects');
    const subjects = document.querySelectorAll('.grid > a');

    function filterSubjects(e) {
        const searchTerm = e.target.value.toLowerCase();
        subjects.forEach(subject => {
            const text = subject.textContent.toLowerCase();
            if (text.includes(searchTerm)) {
                subject.style.display = 'flex';
                setTimeout(() => {
                    subject.style.opacity = '1';
                }, 10);
            } else {
                subject.style.opacity = '0';
                setTimeout(() => {
                    subject.style.display = 'none';
                }, 200);
            }
        });
    }

    searchInput.addEventListener('input', debounce(filterSubjects, 300));
    </script>
</body>
</html>