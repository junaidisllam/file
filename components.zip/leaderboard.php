<?php
require 'db/db.php';
?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Leaderboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        .trophy-gold { color: #FFD700; }
        .trophy-silver { color: #C0C0C0; }
        .trophy-bronze { color: #CD7F32; }
        .leaderboard-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .leaderboard-card:hover {
            transform: translateY(-5px);
        }
        .shine-effect {
            position: relative;
            overflow: hidden;
        }
        .shine-effect::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to right,
                rgba(255, 255, 255, 0) 0%,
                rgba(255, 255, 255, 0.3) 50%,
                rgba(255, 255, 255, 0) 100%
            );
            transform: rotate(30deg);
            animation: shine 3s infinite;
        }
        @keyframes shine {
            0% { transform: rotate(30deg) translateX(-100%); }
            100% { transform: rotate(30deg) translateX(100%); }
        }
        .confetti {
    position: absolute; /* Change from absolute to fixed */
    width: 10px;
    height: 10px;
    pointer-events: none; /* Prevent interference with page interaction */
    z-index: 9999; /* Ensure confetti appears above other elements */
    top: 0;
}

        
        /* Enhanced responsive design */
        @media (max-width: 768px) {
            .responsive-grid {
                grid-template-columns: 1fr;
            }
            .stats-card {
                padding: 0.75rem;
            }
            .leaderboard-grid {
                grid-template-columns: 2fr 8fr 2fr;
            }
            .progress-col {
                display: none;
            }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
 <?php include "./components/navbar.php"; ?>
<main class="container mx-auto px-4 py-6 md:py-8 mb-20">
    <!-- Stats Overview Section -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 mb-8">
        <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl shadow-xl p-6 transform hover:scale-105 transition-all duration-300 stats-card">
            <div class="flex items-center">
                <div class="bg-white/20 p-4 rounded-xl backdrop-blur-sm">
                    <i class="fas fa-users text-white text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-blue-100 text-sm">Total Participants</p>
                    <h3 class="text-3xl font-bold text-white" id="totalParticipants">--</h3>
                </div>
            </div>
        </div>
        
        <div class="bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl shadow-xl p-6 transform hover:scale-105 transition-all duration-300 stats-card">
            <div class="flex items-center">
                <div class="bg-white/20 p-4 rounded-xl backdrop-blur-sm">
                    <i class="fas fa-star text-white text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-purple-100 text-sm">Highest Score</p>
                    <h3 class="text-3xl font-bold text-white" id="highestScore">--</h3>
                </div>
            </div>
        </div>
        
        <div class="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-2xl shadow-xl p-6 transform hover:scale-105 transition-all duration-300 stats-card">
            <div class="flex items-center">
                <div class="bg-white/20 p-4 rounded-xl backdrop-blur-sm">
                    <i class="fas fa-chart-line text-white text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-emerald-100 text-sm">Average Score</p>
                    <h3 class="text-3xl font-bold text-white" id="averageScore">--</h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtering and Time Range -->
    <div class="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-6 mb-8">
        <div class="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div class="flex items-center w-full sm:w-auto">
                <label for="timeRange" class="mr-3 font-medium text-gray-700">Time Range:</label>
                <select id="timeRange" class="bg-white border-2 border-blue-100 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 w-full sm:w-auto transition-all duration-300">
                    <option value="all">All Time</option>
                    <option value="month">This Month</option>
                    <option value="week">This Week</option>
                    <option value="day">Today</option>
                </select>
            </div>
            
            <div class="relative w-full sm:w-64">
                <input type="text" id="searchInput" placeholder="Search by name..." 
                       class="w-full bg-white border-2 border-blue-100 rounded-xl pl-12 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all duration-300">
                <i class="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-400"></i>
            </div>
            
            <button id="refreshBtn" class="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-6 py-2.5 rounded-xl transition-all duration-300 flex items-center w-full sm:w-auto justify-center shadow-lg hover:shadow-xl">
                <i class="fas fa-sync-alt mr-2"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Leaderboard Main Section -->
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8 responsive-grid">
        <!-- Top 3 Winners -->
        <div class="lg:col-span-1 order-2 lg:order-1">
            <div class="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-2xl shadow-xl p-6 text-white">
                <h2 class="text-xl font-bold mb-6 flex items-center">
                    <i class="fas fa-crown text-yellow-300 mr-2 text-2xl"></i>
                    Top Champions
                </h2>
                
                <div id="topWinners" class="space-y-6">
                    <!-- Top 3 winners will be loaded here -->
                </div>
            </div>
        </div>

        <!-- Main Leaderboard -->
        <div class="lg:col-span-3 order-1 lg:order-2">
            <div class="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">Leaderboard</h2>
                    <div class="text-sm text-gray-500 bg-blue-50 px-4 py-2 rounded-xl">
                        <span id="lastUpdated">Last updated: </span>
                    </div>
                </div>

                <!-- Table Header -->
                <div class="grid grid-cols-8 lg:grid-cols-12 gap-4 py-4 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl font-semibold text-white text-sm leaderboard-grid mb-4 shadow-lg">
                    <div class="col-span-1 flex items-center">
                        <i class="fas fa-medal mr-2"></i>
                        <span>Rank</span>
                    </div>
                    <div class="col-span-5 lg:col-span-5 hidden lg:flex  items-center">
                        <i class="fas fa-user mr-2"></i>
                        <span>Participant</span>
                    </div>
                    <div class="col-span-2 lg:col-span-3 text-center flex items-center justify-center max-lg:hidden">
                        <i class="fas fa-star mr-2"></i>
                        <span>Score</span>
                    </div>
                    <div class="hidden lg:flex lg:col-span-3 text-right progress-col items-center justify-end">
                        <i class="fas fa-chart-line mr-2"></i>
                        <span>Progress</span>
                    </div>
                </div>

                <!-- Leaderboard entries -->
                <div id="leaderboard" class="space-y-2 max-h-[600px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-blue-50">
                    <!-- Leaderboard entries will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</main>

    <?php include"./components/footer.php"; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Create confetti animation
        function createConfetti() {
            const colors = ['#FFD700', '#C0C0C0', '#CD7F32', '#ff6b6b', '#48dbfb', '#1dd1a1', '#f368e0'];
            const container = document.querySelector('body');
            
            for (let i = 0; i < 50; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.animationDelay = Math.random() * 5 + 's';
                confetti.style.opacity = '1';
                
                // Randomize shape
                if (Math.random() > 0.5) {
                    confetti.style.borderRadius = '50%';
                }
                
                // Animate
                confetti.animate([
                    { transform: 'translateY(0) rotate(0)', opacity: 1 },
                    { transform: `translateY(${Math.random() * 500 + 500}px) rotate(${Math.random() * 360}deg)`, opacity: 0 }
                ], {
                    duration: Math.random() * 3000 + 3000,
                    easing: 'cubic-bezier(0,0.2,0.8,1)',
                    fill: 'forwards'
                });
                
                container.appendChild(confetti);
                
                // Clean up after animation
                setTimeout(() => {
                    confetti.remove();
                }, 6000);
            }
        }

        // Format numbers with commas
        function formatNumber(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        // Calculate progress percentage
        function calculateProgress(score, maxScore) {
            return Math.min(Math.round((score / maxScore) * 100), 100);
        }

        function updateLeaderboard(data) {
            const leaderboard = $('#leaderboard');
            const topWinners = $('#topWinners');
            leaderboard.empty();
            topWinners.empty();
            
            // Update stats
            $('#totalParticipants').text(data.length);
            $('#highestScore').text(formatNumber(data[0]?.total_score || 0));
            
            // Calculate average score
            const totalScore = data.reduce((sum, user) => sum + parseInt(user.total_score), 0);
            const avgScore = data.length > 0 ? Math.round(totalScore / data.length) : 0;
            $('#averageScore').text(formatNumber(avgScore));
            
            // Update last updated time
            $('#lastUpdated').text('Last updated: ' + new Date().toLocaleTimeString());
            
            // Get highest score for progress calculation
            const highestScore = data[0]?.total_score || 1;
            
            // Populate top winners (top 3)
            const topThree = data.slice(0, 3);
            const trophyClasses = ['trophy-gold', 'trophy-silver', 'trophy-bronze'];
            const trophyIcons = ['fas fa-trophy', 'fas fa-trophy', 'fas fa-trophy'];
            
            topThree.forEach((user, index) => {
                const progressPercent = calculateProgress(user.total_score, highestScore);
                
                topWinners.append(`
                    <div class="shine-effect bg-white bg-opacity-10 rounded-lg p-3 md:p-4 relative">
                        <div class="absolute -top-3 md:-top-4 -right-3 md:-right-4 w-8 h-8 md:w-10 md:h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold shadow-lg text-sm md:text-base">
                            ${index + 1}
                        </div>
                        <div class="flex items-center mb-2 md:mb-3">
                            <div class="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg md:text-xl shadow-md">
                                <img src="${user.profile_pic}" class="w-full h-full object-cover rounded-full">
                            </div>
                            <div class="ml-3 md:ml-4">
                                <h3 class="font-bold text-sm md:text-lg">${user.full_name}</h3>
                                <div class="flex items-center">
                                    <i class="${trophyIcons[index]} ${trophyClasses[index]} mr-1"></i>
                                    <span class="text-xs">${index === 0 ? 'Champion' : (index === 1 ? 'Runner-up' : 'Third Place')}</span>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-xl md:text-2xl font-bold my-2 md:my-3">${formatNumber(user.total_score)} pts</div>
                        <div class="w-full bg-blue-900 rounded-full h-1.5 md:h-2 mt-2">
                            <div class="bg-gradient-to-r from-yellow-400 to-yellow-600 h-1.5 md:h-2 rounded-full" style="width: ${progressPercent}%"></div>
                        </div>
                    </div>
                `);
            });
            
            // Populate main leaderboard (all entries)
            data.forEach((user, index) => {
                const progressPercent = calculateProgress(user.total_score, highestScore);
                let rankDisplay, badgeClass;
                
                if (index < 3) {
                    const trophyColors = ['text-yellow-500', 'text-gray-400', 'text-orange-700'];
                    rankDisplay = `<i class="fas fa-trophy ${trophyColors[index]}"></i>`;
                    badgeClass = ['bg-yellow-500', 'bg-gray-400', 'bg-orange-700'][index];
                } else {
                    rankDisplay = (index + 1);
                    badgeClass = 'bg-blue-600';
                }
                
                const isEven = index % 2 === 0;
                const rowClass = isEven ? 'bg-gray-50' : 'bg-white';
                
                leaderboard.append(`
                    <div class="leaderboard-card grid grid-cols-8 lg:grid-cols-12 gap-2 md:gap-4 items-center py-3 md:py-4 px-2 md:px-4 ${rowClass} rounded-lg hover:bg-blue-50 transition-colors leaderboard-grid">
                        <div class="col-span-1 font-bold text-gray-700 text-sm md:text-base">${rankDisplay}</div>
                        <div class="col-span-5 lg:col-span-5 flex items-center">
                            <div class="w-8 h-8 md:w-10 md:h-10 ${badgeClass} rounded-full flex items-center justify-center text-white font-bold shadow-sm mr-2 md:mr-3 text-xs md:text-sm">
                                <img src="${user.profile_pic}" class="w-full h-full object-cover rounded-full">
                            </div>
                            <div class="overflow-hidden">
                                <h3 class="font-semibold text-sm md:text-base truncate">${user.full_name}</h3>
                                <p class="text-xs text-gray-500 hidden md:block">Member since ${new Date().getFullYear()}</p>
                            </div>
                        </div>
                        <div class="col-span-2 lg:col-span-3 text-center">
                            <span class="font-bold text-sm md:text-lg">${formatNumber(user.total_score)}</span>
                            <span class="text-xs text-gray-500 ml-1 hidden md:inline">pts</span>
                        </div>
                        <div class="hidden lg:flex lg:col-span-3 items-center justify-end progress-col">
                            <div class="w-full max-w-xs">
                                <div class="flex justify-between text-xs mb-1">
                                    <span>Progress</span>
                                    <span>${progressPercent}%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-1.5 md:h-2">
                                    <div class="bg-gradient-to-r from-blue-500 to-indigo-600 h-1.5 md:h-2 rounded-full" style="width: ${progressPercent}%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                `);
            });
        }

        function fetchLeaderboard() {
            const timeRange = $('#timeRange').val();
            const searchTerm = $('#searchInput').val();
            
            $.get('fetch_leaderboard.php', { 
                timeRange: timeRange,
                search: searchTerm
            }, function(data) {
                updateLeaderboard(data);
                
                // Show confetti animation on first load only
                if (!window.confettiShown) {
                    createConfetti();
                    window.confettiShown = true;
                }
            });
        }

        $(document).ready(() => {
            fetchLeaderboard();
            
            // Set up periodic refresh
            setInterval(fetchLeaderboard, 30000);
            
            // Button refresh
            $('#refreshBtn').click(fetchLeaderboard);
            
            // Filter changes
            $('#timeRange').change(fetchLeaderboard);
            
            // Search with debounce
            let searchTimeout;
            $('#searchInput').on('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(fetchLeaderboard, 500);
            });
        });
    </script>
</body>
</html>