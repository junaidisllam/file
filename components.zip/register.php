<?php
require 'db/db.php';

// Set session cookie parameters for 5 years
$lifetime = 60 * 60 * 24 * 365 * 5; // 5 years in seconds
session_set_cookie_params($lifetime, '/');
session_start();

header('Content-Type: application/json');

$response = ['success' => false, 'errors' => []];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $remember_me = isset($_POST['remember_me']); // Check if "Remember Me" is checked

    // Validation
    if (empty($full_name)) {
        $response['errors']['full_name'] = 'Full name is required';
    }
    
    if (empty($phone)) {
        $response['errors']['phone'] = 'Phone number is required';
    } elseif (!preg_match('/^[0-9]{10,15}$/', $phone)) {
        $response['errors']['phone'] = 'Invalid phone number format';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        if ($stmt->fetch()) {
            $response['errors']['phone'] = 'Phone number already registered';
        }
    }

    if (empty($password)) {
        $response['errors']['password'] = 'Password is required';
    } elseif (strlen($password) < 8) {
        $response['errors']['password'] = 'Password must be at least 8 characters';
    }

    if ($password !== $confirm_password) {
        $response['errors']['confirm_password'] = 'Passwords do not match';
    }

    if (empty($response['errors'])) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user into the database
        $stmt = $pdo->prepare("INSERT INTO users (full_name, phone, password) VALUES (?, ?, ?)");
        if ($stmt->execute([$full_name, $phone, $hashed_password])) {
            // Set session variables
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['user_phone'] = $phone;
            $_SESSION['full_name'] = $full_name;

            // Set "Remember Me" cookie if checked
            if ($remember_me) {
                $token = bin2hex(random_bytes(32)); // Generate a secure token
                $expires = date('Y-m-d H:i:s', time() + $lifetime); // 5 years from now

                // Store token in database
                $stmt = $pdo->prepare("INSERT INTO user_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
                $stmt->execute([$_SESSION['user_id'], $token, $expires]);

                // Set cookie
                setcookie('remember_me', $token, time() + $lifetime, '/', '', true, true); // Secure and HttpOnly
            }

            $response['success'] = true;
        } else {
            $response['errors']['database'] = 'Registration failed. Please try again.';
        }
    }
}

echo json_encode($response);
?>